/*
  # Winery Brand Narrative Content Engine - Database Schema

  1. New Tables
    - `winery_profiles` - Store winery information and brand details
    - `content_calendar` - Track content items through the pipeline
    - `research_briefs` - Store AI-generated research and themes
    - `engagement_metrics` - Track content performance metrics
    - `user_roles` - Define user roles and permissions

  2. Security
    - Enable RLS on all tables
    - Add policies for role-based access control
    - Ensure wineries can only access their own data
*/

-- Create enum types
CREATE TYPE user_role AS ENUM ('winery_owner', 'marketing_manager');
CREATE TYPE content_status AS ENUM ('draft', 'ready_for_review', 'scheduled', 'published');
CREATE TYPE content_type AS ENUM ('blog_post', 'social_media', 'newsletter', 'press_release');

-- Winery profiles table
CREATE TABLE IF NOT EXISTS winery_profiles (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES auth.users(id) ON DELETE CASCADE,
  winery_name text NOT NULL,
  location text NOT NULL,
  owner_name text NOT NULL,
  brand_tone text NOT NULL,
  backstory text NOT NULL,
  wines text[] DEFAULT '{}',
  target_audience text NOT NULL,
  weekly_content_goals integer DEFAULT 3,
  wordpress_url text,
  wordpress_username text,
  wordpress_password text,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- User roles table
CREATE TABLE IF NOT EXISTS user_roles (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES auth.users(id) ON DELETE CASCADE,
  winery_id uuid REFERENCES winery_profiles(id) ON DELETE CASCADE,
  role user_role NOT NULL,
  created_at timestamptz DEFAULT now()
);

-- Content calendar table
CREATE TABLE IF NOT EXISTS content_calendar (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  winery_id uuid REFERENCES winery_profiles(id) ON DELETE CASCADE,
  title text NOT NULL,
  content text,
  content_type content_type NOT NULL,
  status content_status DEFAULT 'draft',
  publish_date timestamptz,
  content_url text,
  created_by uuid REFERENCES auth.users(id),
  approved_by uuid REFERENCES auth.users(id),
  approval_comments text,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Research briefs table
CREATE TABLE IF NOT EXISTS research_briefs (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  winery_id uuid REFERENCES winery_profiles(id) ON DELETE CASCADE,
  suggested_theme text NOT NULL,
  key_points text[] DEFAULT '{}',
  local_event_name text,
  local_event_date timestamptz,
  local_event_location text,
  seasonal_context text,
  created_at timestamptz DEFAULT now()
);

-- Engagement metrics table
CREATE TABLE IF NOT EXISTS engagement_metrics (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  content_id uuid REFERENCES content_calendar(id) ON DELETE CASCADE,
  blog_views integer DEFAULT 0,
  email_opens integer DEFAULT 0,
  email_clicks integer DEFAULT 0,
  social_clicks integer DEFAULT 0,
  club_signups integer DEFAULT 0,
  last_updated timestamptz DEFAULT now()
);

-- Enable Row Level Security
ALTER TABLE winery_profiles ENABLE ROW LEVEL SECURITY;
ALTER TABLE user_roles ENABLE ROW LEVEL SECURITY;
ALTER TABLE content_calendar ENABLE ROW LEVEL SECURITY;
ALTER TABLE research_briefs ENABLE ROW LEVEL SECURITY;
ALTER TABLE engagement_metrics ENABLE ROW LEVEL SECURITY;

-- RLS Policies for winery_profiles
CREATE POLICY "Users can read own winery profile"
  ON winery_profiles
  FOR SELECT
  TO authenticated
  USING (user_id = auth.uid());

CREATE POLICY "Users can create own winery profile"
  ON winery_profiles
  FOR INSERT
  TO authenticated
  WITH CHECK (user_id = auth.uid());

CREATE POLICY "Users can update own winery profile"
  ON winery_profiles
  FOR UPDATE
  TO authenticated
  USING (user_id = auth.uid());

-- RLS Policies for user_roles
CREATE POLICY "Users can read roles for their winery"
  ON user_roles
  FOR SELECT
  TO authenticated
  USING (
    user_id = auth.uid() OR 
    winery_id IN (
      SELECT id FROM winery_profiles WHERE user_id = auth.uid()
    )
  );

CREATE POLICY "Winery owners can manage user roles"
  ON user_roles
  FOR ALL
  TO authenticated
  USING (
    winery_id IN (
      SELECT id FROM winery_profiles WHERE user_id = auth.uid()
    )
  );

-- RLS Policies for content_calendar
CREATE POLICY "Users can access content for their winery"
  ON content_calendar
  FOR ALL
  TO authenticated
  USING (
    winery_id IN (
      SELECT wp.id FROM winery_profiles wp
      LEFT JOIN user_roles ur ON wp.id = ur.winery_id
      WHERE wp.user_id = auth.uid() OR ur.user_id = auth.uid()
    )
  );

-- RLS Policies for research_briefs
CREATE POLICY "Users can access research for their winery"
  ON research_briefs
  FOR ALL
  TO authenticated
  USING (
    winery_id IN (
      SELECT wp.id FROM winery_profiles wp
      LEFT JOIN user_roles ur ON wp.id = ur.winery_id
      WHERE wp.user_id = auth.uid() OR ur.user_id = auth.uid()
    )
  );

-- RLS Policies for engagement_metrics
CREATE POLICY "Users can access metrics for their winery content"
  ON engagement_metrics
  FOR ALL
  TO authenticated
  USING (
    content_id IN (
      SELECT cc.id FROM content_calendar cc
      JOIN winery_profiles wp ON cc.winery_id = wp.id
      LEFT JOIN user_roles ur ON wp.id = ur.winery_id
      WHERE wp.user_id = auth.uid() OR ur.user_id = auth.uid()
    )
  );

-- Create indexes for better performance
CREATE INDEX idx_winery_profiles_user_id ON winery_profiles(user_id);
CREATE INDEX idx_user_roles_user_id ON user_roles(user_id);
CREATE INDEX idx_user_roles_winery_id ON user_roles(winery_id);
CREATE INDEX idx_content_calendar_winery_id ON content_calendar(winery_id);
CREATE INDEX idx_content_calendar_status ON content_calendar(status);
CREATE INDEX idx_research_briefs_winery_id ON research_briefs(winery_id);
CREATE INDEX idx_engagement_metrics_content_id ON engagement_metrics(content_id);