import { serve } from 'https://deno.land/std@0.168.0/http/server.ts'
import { createClient } from 'https://esm.sh/@supabase/supabase-js@2'

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
  'Access-Control-Allow-Methods': 'POST, OPTIONS',
}

interface StrategyRequest {
  wineryId: string
  researchBriefIds?: string[]
  timeframe?: 'weekly' | 'monthly' | 'quarterly'
}

serve(async (req) => {
  // Handle CORS preflight requests
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders })
  }

  try {
    // Initialize Supabase client
    const supabaseClient = createClient(
      Deno.env.get('SUPABASE_URL') ?? '',
      Deno.env.get('SUPABASE_SERVICE_ROLE_KEY') ?? ''
    )

    // Get the authorization header
    const authHeader = req.headers.get('Authorization')
    if (!authHeader) {
      throw new Error('No authorization header')
    }

    // Verify the user
    const token = authHeader.replace('Bearer ', '')
    const { data: { user }, error: authError } = await supabaseClient.auth.getUser(token)
    
    if (authError || !user) {
      throw new Error('Invalid authentication')
    }

    // Parse request body
    const { wineryId, researchBriefIds, timeframe = 'weekly' }: StrategyRequest = await req.json()

    if (!wineryId) {
      throw new Error('Winery ID is required')
    }

    // Verify user has access to this winery
    const { data: winery, error: wineryError } = await supabaseClient
      .from('winery_profiles')
      .select('*')
      .eq('id', wineryId)
      .single()

    if (wineryError || !winery) {
      throw new Error('Winery not found')
    }

    // Check if user owns the winery or has access through user_roles
    const { data: userRole } = await supabaseClient
      .from('user_roles')
      .select('*')
      .eq('user_id', user.id)
      .eq('winery_id', wineryId)
      .single()

    if (winery.user_id !== user.id && !userRole) {
      throw new Error('Access denied to this winery')
    }

    // Get recent research briefs
    const { data: researchBriefs, error: researchError } = await supabaseClient
      .from('research_briefs')
      .select('*')
      .eq('winery_id', wineryId)
      .order('created_at', { ascending: false })
      .limit(5)

    if (researchError) {
      console.error('Error fetching research briefs:', researchError)
    }

    // Get existing content for analysis
    const { data: existingContent, error: contentError } = await supabaseClient
      .from('content_calendar')
      .select('*')
      .eq('winery_id', wineryId)
      .order('created_at', { ascending: false })
      .limit(10)

    if (contentError) {
      console.error('Error fetching existing content:', contentError)
    }

    // Generate content strategy using OpenAI
    const strategy = await generateContentStrategy(winery, researchBriefs || [], existingContent || [], timeframe)

    // Return the strategy
    return new Response(
      JSON.stringify({
        success: true,
        strategy,
        timeframe,
        generatedAt: new Date().toISOString()
      }),
      {
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
        status: 200,
      }
    )

  } catch (error) {
    console.error('Error in generate-strategy function:', error)
    
    return new Response(
      JSON.stringify({
        success: false,
        error: error.message || 'An unexpected error occurred'
      }),
      {
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
        status: 400,
      }
    )
  }
})

async function generateContentStrategy(winery: any, researchBriefs: any[], existingContent: any[], timeframe: string) {
  const prompt = `
You are a wine marketing strategist creating a comprehensive content strategy.

WINERY PROFILE:
- Name: ${winery.winery_name}
- Location: ${winery.location}
- Brand Tone: ${winery.brand_tone}
- Target Audience: ${winery.target_audience}
- Wines: ${winery.wines?.join(', ') || 'Various wines'}
- Weekly Content Goals: ${winery.weekly_content_goals || 3}
- Backstory: ${winery.backstory}

RECENT RESEARCH BRIEFS:
${researchBriefs.map(brief => `
- Theme: ${brief.suggested_theme}
- Key Points: ${brief.key_points?.join(', ') || 'None'}
- Local Event: ${brief.local_event_name || 'None'}
- Seasonal Context: ${brief.seasonal_context || 'None'}
`).join('\n')}

EXISTING CONTENT (Last 10 items):
${existingContent.map(content => `
- Title: ${content.title}
- Type: ${content.content_type}
- Status: ${content.status}
- Created: ${new Date(content.created_at).toLocaleDateString()}
`).join('\n')}

TIMEFRAME: ${timeframe}

Create a comprehensive content strategy with the following JSON structure:
{
  "overview": "Strategic overview of the content plan",
  "contentPillars": ["3-4 main content themes/pillars"],
  "recommendedContent": [
    {
      "title": "Suggested content title",
      "type": "blog_post|social_media|newsletter|press_release",
      "priority": "high|medium|low",
      "suggestedPublishDate": "YYYY-MM-DD",
      "keyMessages": ["Main points to cover"],
      "callToAction": "Suggested CTA"
    }
  ],
  "contentCalendar": {
    "week1": ["Content ideas for week 1"],
    "week2": ["Content ideas for week 2"],
    "week3": ["Content ideas for week 3"],
    "week4": ["Content ideas for week 4"]
  },
  "performanceMetrics": ["KPIs to track"],
  "optimizationTips": ["Specific recommendations for improvement"]
}

Focus on:
1. Leveraging research briefs and local events
2. Maintaining brand consistency
3. Engaging the target audience
4. Balancing content types
5. Seasonal relevance
6. Wine education and storytelling
`

  try {
    const openaiResponse = await fetch('https://api.openai.com/v1/chat/completions', {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${Deno.env.get('OPENAI_API_KEY')}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        model: 'gpt-4',
        messages: [
          { role: 'system', content: 'You are a wine marketing strategist who creates comprehensive content strategies for wineries.' },
          { role: 'user', content: prompt }
        ],
        temperature: 0.7,
        max_tokens: 2000,
      }),
    })

    if (!openaiResponse.ok) {
      throw new Error('OpenAI API request failed')
    }

    const openaiData = await openaiResponse.json()
    const strategyText = openaiData.choices[0]?.message?.content

    if (!strategyText) {
      throw new Error('No strategy generated')
    }

    // Parse the JSON response
    const strategy = JSON.parse(strategyText)
    return strategy

  } catch (error) {
    console.error('OpenAI strategy generation error:', error)
    
    // Fallback strategy if OpenAI fails
    return {
      overview: `${timeframe} content strategy for ${winery.winery_name} focusing on brand storytelling and community engagement`,
      contentPillars: [
        'Wine Education & Tasting Notes',
        'Vineyard Stories & Behind-the-Scenes',
        'Local Community & Events',
        'Wine Club & Customer Experiences'
      ],
      recommendedContent: [
        {
          title: 'Our Signature Wine Collection',
          type: 'blog_post',
          priority: 'high',
          suggestedPublishDate: getUpcomingDate(7),
          keyMessages: ['Showcase flagship wines', 'Share tasting notes', 'Include food pairings'],
          callToAction: 'Visit our tasting room or join our wine club'
        },
        {
          title: 'Behind the Scenes: Vineyard Life',
          type: 'social_media',
          priority: 'medium',
          suggestedPublishDate: getUpcomingDate(3),
          keyMessages: ['Show daily vineyard operations', 'Highlight seasonal activities'],
          callToAction: 'Book a vineyard tour'
        }
      ],
      contentCalendar: {
        week1: ['Blog post about wine education', 'Social media vineyard updates'],
        week2: ['Newsletter with wine club benefits', 'Press release about awards'],
        week3: ['Blog post about local events', 'Social media customer spotlights'],
        week4: ['Newsletter with seasonal wine pairings', 'Blog post about winery history']
      },
      performanceMetrics: ['Website traffic', 'Social media engagement', 'Wine club signups', 'Email open rates'],
      optimizationTips: [
        'Post consistently according to your content calendar',
        'Engage with comments and messages promptly',
        'Use high-quality images of wines and vineyard',
        'Include clear calls-to-action in all content'
      ]
    }
  }
}

function getUpcomingDate(daysFromNow: number): string {
  const date = new Date()
  date.setDate(date.getDate() + daysFromNow)
  return date.toISOString().split('T')[0] // Return YYYY-MM-DD format
}