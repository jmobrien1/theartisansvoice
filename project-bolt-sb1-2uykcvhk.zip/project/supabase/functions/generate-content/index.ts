import { serve } from 'https://deno.land/std@0.168.0/http/server.ts'
import { createClient } from 'https://esm.sh/@supabase/supabase-js@2'

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
  'Access-Control-Allow-Methods': 'POST, OPTIONS',
}

interface GenerateContentRequest {
  wineryId: string
  researchBriefId?: string
  contentType: 'blog_post' | 'social_media' | 'newsletter' | 'press_release'
  customPrompt?: string
}

serve(async (req) => {
  // Handle CORS preflight requests
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders })
  }

  try {
    // Initialize Supabase client
    const supabaseClient = createClient(
      Deno.env.get('SUPABASE_URL') ?? '',
      Deno.env.get('SUPABASE_SERVICE_ROLE_KEY') ?? ''
    )

    // Get the authorization header
    const authHeader = req.headers.get('Authorization')
    if (!authHeader) {
      throw new Error('No authorization header')
    }

    // Verify the user
    const token = authHeader.replace('Bearer ', '')
    const { data: { user }, error: authError } = await supabaseClient.auth.getUser(token)
    
    if (authError || !user) {
      throw new Error('Invalid authentication')
    }

    // Parse request body
    const { wineryId, researchBriefId, contentType, customPrompt }: GenerateContentRequest = await req.json()

    if (!wineryId) {
      throw new Error('Winery ID is required')
    }

    // Verify user has access to this winery
    const { data: winery, error: wineryError } = await supabaseClient
      .from('winery_profiles')
      .select('*')
      .eq('id', wineryId)
      .single()

    if (wineryError || !winery) {
      throw new Error('Winery not found')
    }

    // Check if user owns the winery or has access through user_roles
    const { data: userRole } = await supabaseClient
      .from('user_roles')
      .select('*')
      .eq('user_id', user.id)
      .eq('winery_id', wineryId)
      .single()

    if (winery.user_id !== user.id && !userRole) {
      throw new Error('Access denied to this winery')
    }

    // Get research brief if provided
    let researchContext = ''
    if (researchBriefId) {
      const { data: researchBrief } = await supabaseClient
        .from('research_briefs')
        .select('*')
        .eq('id', researchBriefId)
        .eq('winery_id', wineryId)
        .single()

      if (researchBrief) {
        researchContext = `
Research Context:
- Theme: ${researchBrief.suggested_theme}
- Key Points: ${researchBrief.key_points?.join(', ') || 'None'}
- Local Event: ${researchBrief.local_event_name || 'None'}
- Seasonal Context: ${researchBrief.seasonal_context || 'None'}
        `
      }
    }

    // Construct the OpenAI prompt
    const systemPrompt = `You are a professional sommelier and wine content writer. You specialize in creating engaging, authentic content for wineries that captures their unique brand voice and connects with their target audience.

Your writing style should be:
- Warm and inviting, yet knowledgeable
- Storytelling-focused with personal touches
- Educational without being pretentious
- Engaging and conversational
- Authentic to the winery's brand voice

Always include:
- Compelling storytelling elements
- Wine education when relevant
- Call-to-action for wine club or visits
- Seasonal or local connections when applicable`

    const contentPrompt = `
Write a ${contentType.replace('_', ' ')} for ${winery.winery_name} with the following details:

WINERY INFORMATION:
- Name: ${winery.winery_name}
- Location: ${winery.location}
- Owner: ${winery.owner_name}
- Brand Tone: ${winery.brand_tone}
- Backstory: ${winery.backstory}
- Wines: ${winery.wines?.join(', ') || 'Various wines'}
- Target Audience: ${winery.target_audience}

${researchContext}

${customPrompt ? `ADDITIONAL INSTRUCTIONS: ${customPrompt}` : ''}

CONTENT REQUIREMENTS:
- Length: 500-700 words for blog posts, 150-300 words for other content types
- Include a compelling headline
- Write in the winery's brand tone
- Include storytelling elements from the backstory
- Connect with the target audience
- Include a call-to-action
- Make it engaging and authentic

Please format the response as JSON with the following structure:
{
  "title": "Compelling headline here",
  "content": "Full content here with proper paragraphs"
}
`

    // Call OpenAI API
    const openaiResponse = await fetch('https://api.openai.com/v1/chat/completions', {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${Deno.env.get('OPENAI_API_KEY')}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        model: 'gpt-4',
        messages: [
          { role: 'system', content: systemPrompt },
          { role: 'user', content: contentPrompt }
        ],
        temperature: 0.7,
        max_tokens: 1500,
      }),
    })

    if (!openaiResponse.ok) {
      const errorData = await openaiResponse.text()
      console.error('OpenAI API error:', errorData)
      throw new Error('Failed to generate content with OpenAI')
    }

    const openaiData = await openaiResponse.json()
    const generatedText = openaiData.choices[0]?.message?.content

    if (!generatedText) {
      throw new Error('No content generated')
    }

    // Parse the JSON response from OpenAI
    let parsedContent
    try {
      parsedContent = JSON.parse(generatedText)
    } catch (parseError) {
      // If JSON parsing fails, create a structured response
      parsedContent = {
        title: `New ${contentType.replace('_', ' ')} for ${winery.winery_name}`,
        content: generatedText
      }
    }

    // Save the generated content to the database
    const { data: contentItem, error: insertError } = await supabaseClient
      .from('content_calendar')
      .insert({
        winery_id: wineryId,
        title: parsedContent.title,
        content: parsedContent.content,
        content_type: contentType,
        status: 'draft',
        created_by: user.id,
      })
      .select()
      .single()

    if (insertError) {
      console.error('Database insert error:', insertError)
      throw new Error('Failed to save generated content')
    }

    // Return the generated content
    return new Response(
      JSON.stringify({
        success: true,
        contentItem,
        generatedContent: parsedContent
      }),
      {
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
        status: 200,
      }
    )

  } catch (error) {
    console.error('Error in generate-content function:', error)
    
    return new Response(
      JSON.stringify({
        success: false,
        error: error.message || 'An unexpected error occurred'
      }),
      {
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
        status: 400,
      }
    )
  }
})