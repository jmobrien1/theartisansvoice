import { serve } from 'https://deno.land/std@0.168.0/http/server.ts'
import { createClient } from 'https://esm.sh/@supabase/supabase-js@2'

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
  'Access-Control-Allow-Methods': 'POST, OPTIONS',
}

interface ResearchRequest {
  wineryId: string
  location?: string
}

serve(async (req) => {
  // Handle CORS preflight requests
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders })
  }

  try {
    // Initialize Supabase client
    const supabaseClient = createClient(
      Deno.env.get('SUPABASE_URL') ?? '',
      Deno.env.get('SUPABASE_SERVICE_ROLE_KEY') ?? ''
    )

    // Get the authorization header
    const authHeader = req.headers.get('Authorization')
    if (!authHeader) {
      throw new Error('No authorization header')
    }

    // Verify the user
    const token = authHeader.replace('Bearer ', '')
    const { data: { user }, error: authError } = await supabaseClient.auth.getUser(token)
    
    if (authError || !user) {
      throw new Error('Invalid authentication')
    }

    // Parse request body
    const { wineryId, location }: ResearchRequest = await req.json()

    if (!wineryId) {
      throw new Error('Winery ID is required')
    }

    // Verify user has access to this winery
    const { data: winery, error: wineryError } = await supabaseClient
      .from('winery_profiles')
      .select('*')
      .eq('id', wineryId)
      .single()

    if (wineryError || !winery) {
      throw new Error('Winery not found')
    }

    // Check if user owns the winery or has access through user_roles
    const { data: userRole } = await supabaseClient
      .from('user_roles')
      .select('*')
      .eq('user_id', user.id)
      .eq('winery_id', wineryId)
      .single()

    if (winery.user_id !== user.id && !userRole) {
      throw new Error('Access denied to this winery')
    }

    // Get current date and season
    const currentDate = new Date()
    const currentMonth = currentDate.getMonth()
    const currentSeason = getSeason(currentMonth)
    const searchLocation = location || winery.location

    console.log(`Researching events for ${searchLocation} in ${currentSeason}`)

    // Scrape local events (using a mock implementation for demo)
    // In production, you would use services like ScraperAPI, Browserless.io, or Puppeteer
    const scrapedData = await scrapeLocalEvents(searchLocation, currentSeason)

    // Use OpenAI to analyze and summarize the scraped data
    const researchSummary = await analyzeWithOpenAI(scrapedData, winery, currentSeason)

    // Save the research brief to database
    const { data: researchBrief, error: insertError } = await supabaseClient
      .from('research_briefs')
      .insert({
        winery_id: wineryId,
        suggested_theme: researchSummary.theme,
        key_points: researchSummary.keyPoints,
        local_event_name: researchSummary.localEvent?.name,
        local_event_date: researchSummary.localEvent?.date,
        local_event_location: researchSummary.localEvent?.location,
        seasonal_context: researchSummary.seasonalContext,
      })
      .select()
      .single()

    if (insertError) {
      console.error('Database insert error:', insertError)
      throw new Error('Failed to save research brief')
    }

    // Return the research brief
    return new Response(
      JSON.stringify({
        success: true,
        researchBrief,
        scrapedData: scrapedData.summary // Don't return full scraped data for security
      }),
      {
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
        status: 200,
      }
    )

  } catch (error) {
    console.error('Error in generate-research-brief function:', error)
    
    return new Response(
      JSON.stringify({
        success: false,
        error: error.message || 'An unexpected error occurred'
      }),
      {
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
        status: 400,
      }
    )
  }
})

function getSeason(month: number): string {
  if (month >= 2 && month <= 4) return 'Spring'
  if (month >= 5 && month <= 7) return 'Summer'
  if (month >= 8 && month <= 10) return 'Fall'
  return 'Winter'
}

async function scrapeLocalEvents(location: string, season: string) {
  // Mock implementation - in production, use real web scraping
  // This would typically use services like:
  // - ScraperAPI: https://www.scraperapi.com/
  // - Browserless.io: https://www.browserless.io/
  // - Puppeteer with Deno
  
  const mockEvents = [
    {
      name: `${location} Wine Festival`,
      date: getUpcomingDate(30),
      location: location,
      description: `Annual wine festival celebrating local vintners and seasonal wines`,
      type: 'wine_event'
    },
    {
      name: `${season} Harvest Celebration`,
      date: getUpcomingDate(45),
      location: location,
      description: `Community celebration of the ${season.toLowerCase()} harvest season`,
      type: 'seasonal_event'
    },
    {
      name: 'Local Farmers Market',
      date: getUpcomingDate(7),
      location: `${location} Town Square`,
      description: 'Weekly farmers market featuring local produce and artisans',
      type: 'recurring_event'
    }
  ]

  // Simulate web scraping delay
  await new Promise(resolve => setTimeout(resolve, 1000))

  return {
    events: mockEvents,
    summary: `Found ${mockEvents.length} relevant events in ${location} for ${season}`,
    scrapedAt: new Date().toISOString(),
    sources: [
      `Visit ${location} Events Calendar`,
      `${location} Chamber of Commerce`,
      'Local Wine Association'
    ]
  }
}

function getUpcomingDate(daysFromNow: number): string {
  const date = new Date()
  date.setDate(date.getDate() + daysFromNow)
  return date.toISOString()
}

async function analyzeWithOpenAI(scrapedData: any, winery: any, season: string) {
  const prompt = `
You are a wine marketing expert analyzing local events and seasonal trends for content creation.

WINERY CONTEXT:
- Name: ${winery.winery_name}
- Location: ${winery.location}
- Brand Tone: ${winery.brand_tone}
- Target Audience: ${winery.target_audience}
- Wines: ${winery.wines?.join(', ') || 'Various wines'}

SCRAPED EVENT DATA:
${JSON.stringify(scrapedData.events, null, 2)}

CURRENT SEASON: ${season}

Please analyze this data and create a content strategy brief with the following JSON structure:
{
  "theme": "A compelling content theme that connects the winery to local events and seasonal trends",
  "keyPoints": ["3-5 specific content angles or story ideas"],
  "localEvent": {
    "name": "Most relevant upcoming event name",
    "date": "Event date in ISO format",
    "location": "Event location"
  },
  "seasonalContext": "How the current season relates to wine and the local area",
  "contentOpportunities": ["Specific content ideas that leverage the research"]
}

Focus on authentic connections between the winery's brand, local community events, and seasonal wine experiences.
`

  try {
    const openaiResponse = await fetch('https://api.openai.com/v1/chat/completions', {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${Deno.env.get('OPENAI_API_KEY')}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        model: 'gpt-4',
        messages: [
          { role: 'system', content: 'You are a wine marketing expert who creates compelling content strategies based on local events and seasonal trends.' },
          { role: 'user', content: prompt }
        ],
        temperature: 0.7,
        max_tokens: 1000,
      }),
    })

    if (!openaiResponse.ok) {
      throw new Error('OpenAI API request failed')
    }

    const openaiData = await openaiResponse.json()
    const analysisText = openaiData.choices[0]?.message?.content

    if (!analysisText) {
      throw new Error('No analysis generated')
    }

    // Parse the JSON response
    const analysis = JSON.parse(analysisText)
    
    return {
      theme: analysis.theme,
      keyPoints: analysis.keyPoints || [],
      localEvent: analysis.localEvent,
      seasonalContext: analysis.seasonalContext,
      contentOpportunities: analysis.contentOpportunities || []
    }

  } catch (error) {
    console.error('OpenAI analysis error:', error)
    
    // Fallback analysis if OpenAI fails
    const fallbackEvent = scrapedData.events[0]
    return {
      theme: `${season} Wine Experiences in ${winery.location}`,
      keyPoints: [
        `Seasonal wine pairings for ${season.toLowerCase()}`,
        `Local community involvement and events`,
        `Behind-the-scenes vineyard activities`,
        `Wine club member exclusive experiences`
      ],
      localEvent: fallbackEvent ? {
        name: fallbackEvent.name,
        date: fallbackEvent.date,
        location: fallbackEvent.location
      } : null,
      seasonalContext: `${season} brings unique opportunities for wine experiences and community engagement`,
      contentOpportunities: [
        'Blog post about seasonal wine selections',
        'Social media coverage of local events',
        'Newsletter featuring community partnerships'
      ]
    }
  }
}