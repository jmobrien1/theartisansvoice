import { serve } from 'https://deno.land/std@0.168.0/http/server.ts'
import { createClient } from 'https://esm.sh/@supabase/supabase-js@2'

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
  'Access-Control-Allow-Methods': 'POST, OPTIONS',
}

interface PublishRequest {
  contentId: string
}

serve(async (req) => {
  // Handle CORS preflight requests
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders })
  }

  try {
    // Initialize Supabase client
    const supabaseClient = createClient(
      Deno.env.get('SUPABASE_URL') ?? '',
      Deno.env.get('SUPABASE_SERVICE_ROLE_KEY') ?? ''
    )

    // Get the authorization header
    const authHeader = req.headers.get('Authorization')
    if (!authHeader) {
      throw new Error('No authorization header')
    }

    // Verify the user
    const token = authHeader.replace('Bearer ', '')
    const { data: { user }, error: authError } = await supabaseClient.auth.getUser(token)
    
    if (authError || !user) {
      throw new Error('Invalid authentication')
    }

    // Parse request body
    const { contentId }: PublishRequest = await req.json()

    if (!contentId) {
      throw new Error('Content ID is required')
    }

    // Fetch the content item with winery information
    const { data: contentItem, error: contentError } = await supabaseClient
      .from('content_calendar')
      .select(`
        *,
        winery_profiles (
          id,
          winery_name,
          wordpress_url,
          wordpress_username,
          wordpress_password,
          user_id
        )
      `)
      .eq('id', contentId)
      .single()

    if (contentError || !contentItem) {
      throw new Error('Content item not found')
    }

    const winery = contentItem.winery_profiles

    // Verify user has access to this content
    const { data: userRole } = await supabaseClient
      .from('user_roles')
      .select('*')
      .eq('user_id', user.id)
      .eq('winery_id', winery.id)
      .single()

    if (winery.user_id !== user.id && !userRole) {
      throw new Error('Access denied to this content')
    }

    // Check if WordPress credentials are configured
    if (!winery.wordpress_url || !winery.wordpress_username || !winery.wordpress_password) {
      throw new Error('WordPress credentials not configured. Please update your winery settings.')
    }

    // Validate content status
    if (contentItem.status !== 'scheduled' && contentItem.status !== 'ready_for_review') {
      throw new Error('Content must be scheduled or approved before publishing')
    }

    // Prepare WordPress post data
    const wordpressPost = {
      title: contentItem.title,
      content: contentItem.content || '',
      status: 'publish',
      author: 1, // Default to admin user
      categories: [], // Could be enhanced to map content types to categories
      tags: [],
      meta: {
        _winery_content_engine_id: contentItem.id,
        _content_type: contentItem.content_type
      }
    }

    // Create WordPress API URL
    const wpApiUrl = `${winery.wordpress_url.replace(/\/$/, '')}/wp-json/wp/v2/posts`

    // Create Basic Auth header
    const credentials = btoa(`${winery.wordpress_username}:${winery.wordpress_password}`)
    
    // Make request to WordPress REST API
    const wpResponse = await fetch(wpApiUrl, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Basic ${credentials}`,
      },
      body: JSON.stringify(wordpressPost),
    })

    if (!wpResponse.ok) {
      const errorText = await wpResponse.text()
      console.error('WordPress API error:', errorText)
      
      // Handle common WordPress errors
      if (wpResponse.status === 401) {
        throw new Error('WordPress authentication failed. Please check your username and password.')
      } else if (wpResponse.status === 403) {
        throw new Error('WordPress user does not have permission to publish posts.')
      } else if (wpResponse.status === 404) {
        throw new Error('WordPress site not found. Please check your WordPress URL.')
      } else {
        throw new Error(`WordPress publishing failed: ${wpResponse.status} ${wpResponse.statusText}`)
      }
    }

    const wpPostData = await wpResponse.json()

    // Update content status and URL in database
    const { data: updatedContent, error: updateError } = await supabaseClient
      .from('content_calendar')
      .update({
        status: 'published',
        content_url: wpPostData.link,
        publish_date: new Date().toISOString(),
        updated_at: new Date().toISOString()
      })
      .eq('id', contentId)
      .select()
      .single()

    if (updateError) {
      console.error('Database update error:', updateError)
      // Content was published to WordPress but we couldn't update our database
      // This is a partial success scenario
      return new Response(
        JSON.stringify({
          success: true,
          warning: 'Content published to WordPress but database update failed',
          wordpressUrl: wpPostData.link,
          wordpressId: wpPostData.id
        }),
        {
          headers: { ...corsHeaders, 'Content-Type': 'application/json' },
          status: 200,
        }
      )
    }

    // Create engagement metrics entry for the published content
    await supabaseClient
      .from('engagement_metrics')
      .insert({
        content_id: contentId,
        blog_views: 0,
        email_opens: 0,
        email_clicks: 0,
        social_clicks: 0,
        club_signups: 0
      })

    // Return success response
    return new Response(
      JSON.stringify({
        success: true,
        message: 'Content published successfully to WordPress',
        contentItem: updatedContent,
        wordpressUrl: wpPostData.link,
        wordpressId: wpPostData.id
      }),
      {
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
        status: 200,
      }
    )

  } catch (error) {
    console.error('Error in publish-to-wordpress function:', error)
    
    return new Response(
      JSON.stringify({
        success: false,
        error: error.message || 'An unexpected error occurred during publishing'
      }),
      {
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
        status: 400,
      }
    )
  }
})