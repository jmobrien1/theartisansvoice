import { createClient } from '@supabase/supabase-js'

const supabaseUrl = import.meta.env.VITE_SUPABASE_URL || 'https://your-project.supabase.co'
const supabaseAnonKey = import.meta.env.VITE_SUPABASE_ANON_KEY || 'your-anon-key'

export const supabase = createClient(supabaseUrl, supabaseAnonKey)

// Database types
export interface WineryProfile {
  id: string
  user_id: string
  winery_name: string
  location: string
  owner_name: string
  brand_tone: string
  backstory: string
  wines: string[]
  target_audience: string
  weekly_content_goals: number
  wordpress_url?: string
  wordpress_username?: string
  wordpress_password?: string
  created_at: string
  updated_at: string
}

export interface ContentItem {
  id: string
  winery_id: string
  title: string
  content?: string
  content_type: 'blog_post' | 'social_media' | 'newsletter' | 'press_release'
  status: 'draft' | 'ready_for_review' | 'scheduled' | 'published'
  publish_date?: string
  content_url?: string
  created_by?: string
  approved_by?: string
  approval_comments?: string
  created_at: string
  updated_at: string
}

export interface ResearchBrief {
  id: string
  winery_id: string
  suggested_theme: string
  key_points: string[]
  local_event_name?: string
  local_event_date?: string
  local_event_location?: string
  seasonal_context?: string
  created_at: string
}

export interface EngagementMetrics {
  id: string
  content_id: string
  blog_views: number
  email_opens: number
  email_clicks: number
  social_clicks: number
  club_signups: number
  last_updated: string
}

export interface UserRole {
  id: string
  user_id: string
  winery_id: string
  role: 'winery_owner' | 'marketing_manager'
  created_at: string
}