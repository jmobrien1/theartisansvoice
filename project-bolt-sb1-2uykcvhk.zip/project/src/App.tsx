import React from 'react'
import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom'
import { Toaster } from 'react-hot-toast'
import { useAuth } from './hooks/useAuth'
import { useWinery } from './hooks/useWinery'
import { AuthForm } from './components/auth/AuthForm'
import { OnboardingWizard } from './components/onboarding/OnboardingWizard'
import { Dashboard } from './components/Dashboard'

function AppContent() {
  const { user, loading: authLoading } = useAuth()
  const { winery, loading: wineryLoading } = useWinery()

  // Show loading while checking authentication and winery status
  if (authLoading || (user && wineryLoading)) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-burgundy-50 via-white to-amber-50 flex items-center justify-center">
        <div className="text-center">
          <div className="w-16 h-16 bg-gradient-to-br from-burgundy-600 to-burgundy-700 rounded-2xl flex items-center justify-center mx-auto mb-4">
            <div className="w-8 h-8 border-2 border-white border-t-transparent rounded-full animate-spin" />
          </div>
          <p className="text-gray-600">Loading your content engine...</p>
        </div>
      </div>
    )
  }

  // If no user is authenticated, show auth form
  if (!user) {
    return <AuthForm />
  }

  // If user is authenticated but no winery profile exists, show onboarding
  if (!winery) {
    return <OnboardingWizard />
  }

  // If user is authenticated and has a winery profile, show dashboard
  return <Dashboard />
}

function App() {
  return (
    <BrowserRouter>
      <div className="App">
        <Routes>
          <Route path="/*" element={<AppContent />} />
        </Routes>
        <Toaster
          position="top-right"
          toastOptions={{
            duration: 4000,
            style: {
              background: '#fff',
              color: '#374151',
              border: '1px solid #e5e7eb',
              borderRadius: '12px',
              boxShadow: '0 10px 25px -5px rgba(0, 0, 0, 0.1), 0 10px 10px -5px rgba(0, 0, 0, 0.04)',
            },
          }}
        />
      </div>
    </BrowserRouter>
  )
}

export default App