import { useState, useEffect } from 'react'
import { WineryProfile, UserRole, supabase } from '../lib/supabase'
import { useAuth } from './useAuth'

export function useWinery() {
  const { user } = useAuth()
  const [winery, setWinery] = useState<WineryProfile | null>(null)
  const [userRole, setUserRole] = useState<UserRole | null>(null)
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    if (user) {
      fetchWineryData()
    } else {
      setWinery(null)
      setUserRole(null)
      setLoading(false)
    }
  }, [user])

  const fetchWineryData = async () => {
    if (!user) {
      setLoading(false)
      return
    }

    try {
      setLoading(true)
      
      // First, check if user owns a winery
      const { data: ownedWinery, error: wineryError } = await supabase
        .from('winery_profiles')
        .select('*')
        .eq('user_id', user.id)
        .maybeSingle()

      if (wineryError) {
        console.error('Error fetching winery:', wineryError)
        setLoading(false)
        return
      }

      if (ownedWinery) {
        setWinery(ownedWinery)
        setUserRole({
          id: '',
          user_id: user.id,
          winery_id: ownedWinery.id,
          role: 'winery_owner',
          created_at: new Date().toISOString()
        })
      } else {
        // Check if user is assigned to a winery as marketing manager
        const { data: roleData, error: roleError } = await supabase
          .from('user_roles')
          .select('*, winery_profiles(*)')
          .eq('user_id', user.id)
          .maybeSingle()

        if (roleError) {
          console.error('Error fetching user role:', roleError)
        } else if (roleData && roleData.winery_profiles) {
          setWinery(roleData.winery_profiles as WineryProfile)
          setUserRole(roleData as UserRole)
        }
      }
    } catch (error) {
      console.error('Error fetching winery data:', error)
    } finally {
      setLoading(false)
    }
  }

  const createWinery = async (wineryData: Omit<WineryProfile, 'id' | 'user_id' | 'created_at' | 'updated_at'>) => {
    if (!user) throw new Error('User not authenticated')

    try {
      const { data, error } = await supabase
        .from('winery_profiles')
        .insert({
          ...wineryData,
          user_id: user.id,
        })
        .select()
        .single()

      if (error) {
        console.error('Supabase error:', error)
        throw new Error(error.message || 'Failed to create winery profile')
      }

      setWinery(data)
      setUserRole({
        id: '',
        user_id: user.id,
        winery_id: data.id,
        role: 'winery_owner',
        created_at: new Date().toISOString()
      })

      return data
    } catch (error) {
      console.error('Error creating winery:', error)
      throw error
    }
  }

  return {
    winery,
    userRole,
    loading,
    createWinery,
    refetch: fetchWineryData,
  }
}