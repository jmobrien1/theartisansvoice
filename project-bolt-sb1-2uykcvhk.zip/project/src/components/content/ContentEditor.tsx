import React, { useState, useEffect } from 'react'
import { motion } from 'framer-motion'
import ReactQuill from 'react-quill'
import 'react-quill/dist/quill.snow.css'
import { 
  Save, 
  X, 
  Eye, 
  Edit3, 
  Clock, 
  CheckCircle, 
  Calendar,
  FileText,
  MessageSquare,
  Mail,
  Newspaper
} from 'lucide-react'
import { Button } from '../ui/Button'
import { Input } from '../ui/Input'
import { ContentItem, supabase } from '../../lib/supabase'
import { useWinery } from '../../hooks/useWinery'
import toast from 'react-hot-toast'

interface ContentEditorProps {
  item: ContentItem
  onClose: () => void
  onSave: (updatedItem: ContentItem) => void
}

export function ContentEditor({ item, onClose, onSave }: ContentEditorProps) {
  const { winery } = useWinery()
  const [title, setTitle] = useState(item.title)
  const [content, setContent] = useState(item.content || '')
  const [status, setStatus] = useState(item.status)
  const [publishDate, setPublishDate] = useState(
    item.publish_date ? new Date(item.publish_date).toISOString().slice(0, 16) : ''
  )
  const [saving, setSaving] = useState(false)
  const [previewMode, setPreviewMode] = useState(false)
  const [approvalComments, setApprovalComments] = useState(item.approval_comments || '')

  const typeConfig = {
    blog_post: { label: 'Blog Post', icon: FileText, color: 'purple' },
    social_media: { label: 'Social Media', icon: MessageSquare, color: 'pink' },
    newsletter: { label: 'Newsletter', icon: Mail, color: 'blue' },
    press_release: { label: 'Press Release', icon: Newspaper, color: 'indigo' }
  }

  const statusConfig = {
    draft: { color: 'gray', label: 'Draft', icon: FileText },
    ready_for_review: { color: 'yellow', label: 'Ready for Review', icon: Eye },
    scheduled: { color: 'blue', label: 'Scheduled', icon: Calendar },
    published: { color: 'green', label: 'Published', icon: CheckCircle }
  }

  // Rich text editor modules configuration
  const modules = {
    toolbar: [
      [{ 'header': [1, 2, 3, false] }],
      ['bold', 'italic', 'underline', 'strike'],
      [{ 'list': 'ordered'}, { 'list': 'bullet' }],
      [{ 'indent': '-1'}, { 'indent': '+1' }],
      ['link'],
      [{ 'align': [] }],
      ['blockquote'],
      ['clean']
    ],
  }

  const formats = [
    'header', 'bold', 'italic', 'underline', 'strike',
    'list', 'bullet', 'indent', 'link', 'align', 'blockquote'
  ]

  const handleSave = async () => {
    if (!title.trim()) {
      toast.error('Title is required')
      return
    }

    setSaving(true)
    try {
      const updateData: Partial<ContentItem> = {
        title: title.trim(),
        content: content,
        status: status,
        publish_date: publishDate ? new Date(publishDate).toISOString() : null,
        approval_comments: approvalComments || null,
        updated_at: new Date().toISOString()
      }

      const { data, error } = await supabase
        .from('content_calendar')
        .update(updateData)
        .eq('id', item.id)
        .select()
        .single()

      if (error) throw error

      toast.success('Content saved successfully!')
      onSave(data)
      onClose()
    } catch (error: any) {
      console.error('Error saving content:', error)
      toast.error(error.message || 'Failed to save content')
    } finally {
      setSaving(false)
    }
  }

  const handleStatusChange = (newStatus: ContentItem['status']) => {
    setStatus(newStatus)
    
    // Auto-set publish date when scheduling
    if (newStatus === 'scheduled' && !publishDate) {
      const tomorrow = new Date()
      tomorrow.setDate(tomorrow.getDate() + 1)
      tomorrow.setHours(9, 0, 0, 0) // Default to 9 AM
      setPublishDate(tomorrow.toISOString().slice(0, 16))
    }
  }

  const getWordCount = (text: string) => {
    // Remove HTML tags and count words
    const plainText = text.replace(/<[^>]*>/g, ' ').replace(/\s+/g, ' ').trim()
    return plainText ? plainText.split(' ').length : 0
  }

  const wordCount = getWordCount(content)
  const typeInfo = typeConfig[item.content_type]
  const TypeIcon = typeInfo.icon

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="fixed inset-0 bg-black/50 flex items-center justify-center p-4 z-50"
      onClick={onClose}
    >
      <motion.div
        initial={{ scale: 0.9, opacity: 0 }}
        animate={{ scale: 1, opacity: 1 }}
        exit={{ scale: 0.9, opacity: 0 }}
        className="bg-white rounded-xl shadow-2xl w-full max-w-6xl max-h-[90vh] overflow-hidden flex flex-col"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="flex items-center justify-between p-6 border-b border-gray-200 bg-gray-50">
          <div className="flex items-center space-x-3">
            <div className={`w-10 h-10 bg-${typeInfo.color}-100 rounded-lg flex items-center justify-center`}>
              <TypeIcon className={`w-5 h-5 text-${typeInfo.color}-600`} />
            </div>
            <div>
              <h2 className="text-xl font-bold text-gray-900">Content Editor</h2>
              <div className="flex items-center space-x-2 text-sm text-gray-600">
                <span className={`px-2 py-1 rounded-full bg-${typeInfo.color}-100 text-${typeInfo.color}-800 text-xs font-medium`}>
                  {typeInfo.label}
                </span>
                <span>•</span>
                <span>{wordCount} words</span>
              </div>
            </div>
          </div>
          
          <div className="flex items-center space-x-2">
            <Button
              variant="ghost"
              size="sm"
              onClick={() => setPreviewMode(!previewMode)}
            >
              {previewMode ? <Edit3 className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
              {previewMode ? 'Edit' : 'Preview'}
            </Button>
            <Button
              variant="ghost"
              size="sm"
              onClick={onClose}
            >
              <X className="w-5 h-5" />
            </Button>
          </div>
        </div>

        {/* Content */}
        <div className="flex-1 overflow-hidden flex">
          {/* Main Editor */}
          <div className="flex-1 flex flex-col">
            <div className="p-6 space-y-4">
              {/* Title */}
              <Input
                label="Title"
                value={title}
                onChange={(e) => setTitle(e.target.value)}
                placeholder="Enter content title..."
                className="text-lg font-semibold"
              />

              {/* Content Editor */}
              <div className="space-y-2">
                <label className="block text-sm font-medium text-gray-700">
                  Content
                </label>
                {previewMode ? (
                  <div className="min-h-[400px] p-4 border border-gray-300 rounded-lg bg-gray-50">
                    <div 
                      className="prose max-w-none"
                      dangerouslySetInnerHTML={{ __html: content }}
                    />
                  </div>
                ) : (
                  <div className="border border-gray-300 rounded-lg overflow-hidden">
                    <ReactQuill
                      theme="snow"
                      value={content}
                      onChange={setContent}
                      modules={modules}
                      formats={formats}
                      placeholder="Start writing your content..."
                      style={{ height: '400px' }}
                    />
                  </div>
                )}
              </div>
            </div>
          </div>

          {/* Sidebar */}
          <div className="w-80 border-l border-gray-200 bg-gray-50 p-6 space-y-6 overflow-y-auto">
            {/* Status */}
            <div className="space-y-3">
              <h3 className="font-semibold text-gray-900">Status</h3>
              <div className="space-y-2">
                {Object.entries(statusConfig).map(([statusKey, config]) => {
                  const StatusIcon = config.icon
                  const isSelected = status === statusKey
                  
                  return (
                    <button
                      key={statusKey}
                      onClick={() => handleStatusChange(statusKey as ContentItem['status'])}
                      className={`w-full flex items-center space-x-3 p-3 rounded-lg border transition-all ${
                        isSelected
                          ? `bg-${config.color}-50 border-${config.color}-200 text-${config.color}-800`
                          : 'bg-white border-gray-200 text-gray-600 hover:bg-gray-50'
                      }`}
                    >
                      <StatusIcon className="w-4 h-4" />
                      <span className="text-sm font-medium">{config.label}</span>
                    </button>
                  )
                })}
              </div>
            </div>

            {/* Publish Date */}
            {(status === 'scheduled' || status === 'published') && (
              <div className="space-y-2">
                <label className="block text-sm font-medium text-gray-700">
                  {status === 'published' ? 'Published Date' : 'Publish Date'}
                </label>
                <input
                  type="datetime-local"
                  value={publishDate}
                  onChange={(e) => setPublishDate(e.target.value)}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-burgundy-500 focus:border-burgundy-500"
                  disabled={status === 'published'}
                />
              </div>
            )}

            {/* Approval Comments */}
            {(status === 'ready_for_review' || approvalComments) && (
              <div className="space-y-2">
                <label className="block text-sm font-medium text-gray-700">
                  Review Comments
                </label>
                <textarea
                  value={approvalComments}
                  onChange={(e) => setApprovalComments(e.target.value)}
                  placeholder="Add review comments or feedback..."
                  rows={3}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-burgundy-500 focus:border-burgundy-500 text-sm"
                />
              </div>
            )}

            {/* Content Stats */}
            <div className="space-y-3">
              <h3 className="font-semibold text-gray-900">Content Stats</h3>
              <div className="space-y-2 text-sm">
                <div className="flex justify-between">
                  <span className="text-gray-600">Word Count:</span>
                  <span className="font-medium">{wordCount}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-600">Type:</span>
                  <span className="font-medium">{typeInfo.label}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-600">Created:</span>
                  <span className="font-medium">
                    {new Date(item.created_at).toLocaleDateString()}
                  </span>
                </div>
                {item.updated_at && (
                  <div className="flex justify-between">
                    <span className="text-gray-600">Updated:</span>
                    <span className="font-medium">
                      {new Date(item.updated_at).toLocaleDateString()}
                    </span>
                  </div>
                )}
              </div>
            </div>

            {/* Content Guidelines */}
            <div className="space-y-3">
              <h3 className="font-semibold text-gray-900">Guidelines</h3>
              <div className="text-xs text-gray-600 space-y-1">
                {item.content_type === 'blog_post' && (
                  <>
                    <p>• Aim for 500-700 words</p>
                    <p>• Include compelling storytelling</p>
                    <p>• Add call-to-action</p>
                    <p>• Use brand voice consistently</p>
                  </>
                )}
                {item.content_type === 'social_media' && (
                  <>
                    <p>• Keep under 280 characters for Twitter</p>
                    <p>• Use engaging visuals</p>
                    <p>• Include relevant hashtags</p>
                    <p>• Encourage engagement</p>
                  </>
                )}
                {item.content_type === 'newsletter' && (
                  <>
                    <p>• Clear subject line</p>
                    <p>• Scannable content</p>
                    <p>• Include wine club benefits</p>
                    <p>• Strong call-to-action</p>
                  </>
                )}
                {item.content_type === 'press_release' && (
                  <>
                    <p>• Lead with key news</p>
                    <p>• Include quotes</p>
                    <p>• Provide contact information</p>
                    <p>• Follow AP style</p>
                  </>
                )}
              </div>
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="flex items-center justify-between p-6 border-t border-gray-200 bg-gray-50">
          <div className="text-sm text-gray-600">
            Last saved: {item.updated_at ? new Date(item.updated_at).toLocaleString() : 'Never'}
          </div>
          
          <div className="flex items-center space-x-3">
            <Button
              variant="ghost"
              onClick={onClose}
            >
              Cancel
            </Button>
            <Button
              onClick={handleSave}
              loading={saving}
            >
              <Save className="w-4 h-4 mr-2" />
              Save Changes
            </Button>
          </div>
        </div>
      </motion.div>
    </motion.div>
  )
}