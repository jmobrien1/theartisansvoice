import React, { useState, useEffect, useCallback } from 'react'
import { motion } from 'framer-motion'
import { Calendar, momentLocalizer, Views, View } from 'react-big-calendar'
import moment from 'moment'
import 'react-big-calendar/lib/css/react-big-calendar.css'
import { 
  Calendar as CalendarIcon, 
  Plus, 
  Filter, 
  ChevronLeft, 
  ChevronRight,
  FileText,
  Clock,
  CheckCircle,
  Eye,
  Edit3,
  ExternalLink,
  Globe
} from 'lucide-react'
import { Card } from '../ui/Card'
import { Button } from '../ui/Button'
import { ContentItem, supabase } from '../../lib/supabase'
import { useWinery } from '../../hooks/useWinery'
import { ContentEditor } from '../content/ContentEditor'
import toast from 'react-hot-toast'

const localizer = momentLocalizer(moment)

interface CalendarEvent {
  id: string
  title: string
  start: Date
  end: Date
  resource: ContentItem
  color: string
}

export function ContentCalendar() {
  const { winery } = useWinery()
  const [contentItems, setContentItems] = useState<ContentItem[]>([])
  const [events, setEvents] = useState<CalendarEvent[]>([])
  const [loading, setLoading] = useState(true)
  const [selectedEvent, setSelectedEvent] = useState<CalendarEvent | null>(null)
  const [editingItem, setEditingItem] = useState<ContentItem | null>(null)
  const [currentView, setCurrentView] = useState<View>(Views.MONTH)
  const [currentDate, setCurrentDate] = useState(new Date())
  const [filterStatus, setFilterStatus] = useState<string>('all')

  // Fetch content items
  useEffect(() => {
    if (winery) {
      fetchContentItems()
    }
  }, [winery])

  // Convert content items to calendar events
  useEffect(() => {
    const calendarEvents = contentItems
      .filter(item => {
        if (filterStatus === 'all') return true
        return item.status === filterStatus
      })
      .filter(item => item.publish_date || item.status === 'published')
      .map(item => {
        const eventDate = item.publish_date ? new Date(item.publish_date) : new Date(item.created_at)
        
        // Set event duration based on content type
        const endDate = new Date(eventDate)
        endDate.setHours(eventDate.getHours() + 1) // 1 hour duration for display

        const statusColors = {
          draft: '#6b7280',
          ready_for_review: '#f59e0b',
          scheduled: '#3b82f6',
          published: '#10b981'
        }

        return {
          id: item.id,
          title: item.title,
          start: eventDate,
          end: endDate,
          resource: item,
          color: statusColors[item.status]
        }
      })

    setEvents(calendarEvents)
  }, [contentItems, filterStatus])

  const fetchContentItems = async () => {
    if (!winery) return

    try {
      setLoading(true)
      const { data, error } = await supabase
        .from('content_calendar')
        .select('*')
        .eq('winery_id', winery.id)
        .order('created_at', { ascending: false })

      if (error) throw error
      setContentItems(data || [])
    } catch (error) {
      console.error('Error fetching content items:', error)
      toast.error('Failed to load content items')
    } finally {
      setLoading(false)
    }
  }

  const handleSelectEvent = useCallback((event: CalendarEvent) => {
    setSelectedEvent(event)
  }, [])

  const handleSelectSlot = useCallback(({ start }: { start: Date }) => {
    // Create new content item for selected date
    toast.success(`Create new content for ${moment(start).format('MMMM Do, YYYY')}`)
  }, [])

  const handleEventDrop = async ({ event, start, end }: { event: CalendarEvent, start: Date, end: Date }) => {
    try {
      // Update the publish date in the database
      const { error } = await supabase
        .from('content_calendar')
        .update({
          publish_date: start.toISOString(),
          updated_at: new Date().toISOString()
        })
        .eq('id', event.id)

      if (error) throw error

      // Update local state
      setContentItems(prev => 
        prev.map(item => 
          item.id === event.id 
            ? { ...item, publish_date: start.toISOString() }
            : item
        )
      )

      toast.success('Content rescheduled successfully!')
    } catch (error) {
      console.error('Error rescheduling content:', error)
      toast.error('Failed to reschedule content')
    }
  }

  const handleContentSave = (updatedItem: ContentItem) => {
    setContentItems(prev => 
      prev.map(item => item.id === updatedItem.id ? updatedItem : item)
    )
    setSelectedEvent(null)
  }

  const eventStyleGetter = (event: CalendarEvent) => {
    return {
      style: {
        backgroundColor: event.color,
        borderRadius: '6px',
        opacity: 0.8,
        color: 'white',
        border: '0px',
        display: 'block',
        fontSize: '12px',
        padding: '2px 4px'
      }
    }
  }

  const CustomToolbar = ({ label, onNavigate, onView }: any) => (
    <div className="flex items-center justify-between mb-6 p-4 bg-white rounded-lg border border-gray-200">
      <div className="flex items-center space-x-4">
        <h2 className="text-xl font-bold text-gray-900">{label}</h2>
        <div className="flex items-center space-x-2">
          <Button
            variant="ghost"
            size="sm"
            onClick={() => onNavigate('PREV')}
          >
            <ChevronLeft className="w-4 h-4" />
          </Button>
          <Button
            variant="ghost"
            size="sm"
            onClick={() => onNavigate('TODAY')}
          >
            Today
          </Button>
          <Button
            variant="ghost"
            size="sm"
            onClick={() => onNavigate('NEXT')}
          >
            <ChevronRight className="w-4 h-4" />
          </Button>
        </div>
      </div>

      <div className="flex items-center space-x-4">
        <select
          value={filterStatus}
          onChange={(e) => setFilterStatus(e.target.value)}
          className="px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-burgundy-500 focus:border-burgundy-500 text-sm"
        >
          <option value="all">All Status</option>
          <option value="draft">Draft</option>
          <option value="ready_for_review">Ready for Review</option>
          <option value="scheduled">Scheduled</option>
          <option value="published">Published</option>
        </select>

        <div className="flex items-center space-x-1 bg-gray-100 rounded-lg p-1">
          <Button
            variant={currentView === Views.MONTH ? 'primary' : 'ghost'}
            size="sm"
            onClick={() => onView(Views.MONTH)}
          >
            Month
          </Button>
          <Button
            variant={currentView === Views.WEEK ? 'primary' : 'ghost'}
            size="sm"
            onClick={() => onView(Views.WEEK)}
          >
            Week
          </Button>
          <Button
            variant={currentView === Views.AGENDA ? 'primary' : 'ghost'}
            size="sm"
            onClick={() => onView(Views.AGENDA)}
          >
            Agenda
          </Button>
        </div>
      </div>
    </div>
  )

  const statusConfig = {
    draft: { color: 'gray', label: 'Draft', icon: FileText },
    ready_for_review: { color: 'yellow', label: 'Ready for Review', icon: Eye },
    scheduled: { color: 'blue', label: 'Scheduled', icon: Clock },
    published: { color: 'green', label: 'Published', icon: CheckCircle }
  }

  if (!winery) {
    return (
      <div className="text-center py-12">
        <h2 className="text-2xl font-bold text-gray-900 mb-4">Content Calendar</h2>
        <p className="text-gray-600">Please complete your winery setup to access the content calendar.</p>
      </div>
    )
  }

  if (loading) {
    return (
      <div className="text-center py-12">
        <div className="w-16 h-16 bg-gradient-to-br from-burgundy-600 to-burgundy-700 rounded-2xl flex items-center justify-center mx-auto mb-4">
          <div className="w-8 h-8 border-2 border-white border-t-transparent rounded-full animate-spin" />
        </div>
        <p className="text-gray-600">Loading content calendar...</p>
      </div>
    )
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between gap-4">
        <div>
          <h1 className="text-3xl font-bold text-gray-900">Content Calendar</h1>
          <p className="text-gray-600 mt-1">
            Visual overview of your content publishing schedule
          </p>
        </div>
        <Button size="lg">
          <Plus className="w-5 h-5 mr-2" />
          Schedule Content
        </Button>
      </div>

      {/* Legend */}
      <Card className="p-4">
        <div className="flex items-center justify-between">
          <h3 className="font-semibold text-gray-900">Status Legend</h3>
          <div className="flex items-center space-x-6">
            {Object.entries(statusConfig).map(([status, config]) => {
              const StatusIcon = config.icon
              return (
                <div key={status} className="flex items-center space-x-2">
                  <div className={`w-3 h-3 rounded-full bg-${config.color}-500`} />
                  <StatusIcon className={`w-4 h-4 text-${config.color}-600`} />
                  <span className="text-sm text-gray-700">{config.label}</span>
                </div>
              )
            })}
          </div>
        </div>
      </Card>

      {/* Calendar */}
      <Card className="p-6">
        <div style={{ height: '600px' }}>
          <Calendar
            localizer={localizer}
            events={events}
            startAccessor="start"
            endAccessor="end"
            onSelectEvent={handleSelectEvent}
            onSelectSlot={handleSelectSlot}
            onEventDrop={handleEventDrop}
            eventPropGetter={eventStyleGetter}
            view={currentView}
            onView={setCurrentView}
            date={currentDate}
            onNavigate={setCurrentDate}
            selectable
            resizable
            dragAndDropAccessor="id"
            components={{
              toolbar: CustomToolbar
            }}
            formats={{
              eventTimeRangeFormat: () => '',
              agendaTimeRangeFormat: () => '',
            }}
            popup
            popupOffset={30}
          />
        </div>
      </Card>

      {/* Event Detail Modal */}
      {selectedEvent && !editingItem && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          className="fixed inset-0 bg-black/50 flex items-center justify-center p-4 z-50"
          onClick={() => setSelectedEvent(null)}
        >
          <motion.div
            initial={{ scale: 0.9, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            exit={{ scale: 0.9, opacity: 0 }}
            className="bg-white rounded-xl shadow-2xl max-w-2xl w-full max-h-[80vh] overflow-y-auto"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="p-6">
              <div className="flex items-start justify-between mb-4">
                <div>
                  <h2 className="text-xl font-bold text-gray-900 mb-2">
                    {selectedEvent.resource.title}
                  </h2>
                  <div className="flex items-center space-x-3">
                    <span className={`text-xs font-medium px-2 py-1 rounded-full bg-${statusConfig[selectedEvent.resource.status].color}-100 text-${statusConfig[selectedEvent.resource.status].color}-800`}>
                      {statusConfig[selectedEvent.resource.status].label}
                    </span>
                    <span className="text-sm text-gray-600">
                      {moment(selectedEvent.start).format('MMMM Do, YYYY [at] h:mm A')}
                    </span>
                  </div>
                </div>
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={() => setSelectedEvent(null)}
                >
                  ×
                </Button>
              </div>

              {selectedEvent.resource.content && (
                <div className="mb-6">
                  <h3 className="font-semibold text-gray-900 mb-2">Content Preview</h3>
                  <div 
                    className="prose max-w-none text-gray-700 bg-gray-50 p-4 rounded-lg max-h-40 overflow-y-auto"
                    dangerouslySetInnerHTML={{ __html: selectedEvent.resource.content }}
                  />
                </div>
              )}

              <div className="flex space-x-3">
                <Button 
                  size="sm"
                  onClick={() => {
                    setEditingItem(selectedEvent.resource)
                    setSelectedEvent(null)
                  }}
                >
                  <Edit3 className="w-4 h-4 mr-2" />
                  Edit Content
                </Button>
                
                {selectedEvent.resource.content_url && (
                  <Button 
                    variant="outline" 
                    size="sm"
                    onClick={() => window.open(selectedEvent.resource.content_url, '_blank')}
                  >
                    <ExternalLink className="w-4 h-4 mr-2" />
                    View Published
                  </Button>
                )}
              </div>
            </div>
          </motion.div>
        </motion.div>
      )}

      {/* Content Editor Modal */}
      {editingItem && (
        <ContentEditor
          item={editingItem}
          onClose={() => setEditingItem(null)}
          onSave={handleContentSave}
        />
      )}
    </div>
  )
}