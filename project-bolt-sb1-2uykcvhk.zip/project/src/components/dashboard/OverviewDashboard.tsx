import React from 'react'
import { motion } from 'framer-motion'
import { 
  TrendingUp, 
  FileText, 
  Clock, 
  CheckCircle, 
  Users, 
  Eye,
  MousePointer,
  UserPlus,
  Calendar,
  Sparkles
} from 'lucide-react'
import { Card } from '../ui/Card'
import { Button } from '../ui/Button'

interface OverviewDashboardProps {
  onNavigate: (view: string) => void
}

export function OverviewDashboard({ onNavigate }: OverviewDashboardProps) {
  // Mock data - in a real app, this would come from your database
  const stats = [
    {
      title: 'Total Content',
      value: '24',
      change: '+12%',
      trend: 'up',
      icon: FileText,
      color: 'from-blue-500 to-blue-600'
    },
    {
      title: 'Published This Week',
      value: '3',
      change: '+50%',
      trend: 'up',
      icon: CheckCircle,
      color: 'from-green-500 to-green-600'
    },
    {
      title: 'Pending Review',
      value: '2',
      change: '-25%',
      trend: 'down',
      icon: Clock,
      color: 'from-amber-500 to-amber-600'
    },
    {
      title: 'Total Views',
      value: '1,247',
      change: '+18%',
      trend: 'up',
      icon: Eye,
      color: 'from-purple-500 to-purple-600'
    }
  ]

  const recentActivity = [
    {
      id: 1,
      type: 'content_created',
      title: 'New blog post drafted: "Spring Wine Tasting Events"',
      time: '2 hours ago',
      icon: FileText
    },
    {
      id: 2,
      type: 'content_published',
      title: 'Published: "Our 2024 Harvest Story"',
      time: '1 day ago',
      icon: CheckCircle
    },
    {
      id: 3,
      type: 'research_generated',
      title: 'AI Research: "Valentine\'s Day Wine Pairing"',
      time: '2 days ago',
      icon: Sparkles
    },
    {
      id: 4,
      type: 'metrics_updated',
      title: 'Analytics updated for December content',
      time: '3 days ago',
      icon: TrendingUp
    }
  ]

  const quickActions = [
    {
      title: 'Generate Weekly Plan',
      description: 'Let AI create your content calendar',
      icon: Calendar,
      action: () => onNavigate('agents'),
      variant: 'primary' as const
    },
    {
      title: 'Draft New Post',
      description: 'Start writing content manually',
      icon: FileText,
      action: () => onNavigate('content'),
      variant: 'secondary' as const
    },
    {
      title: 'View Analytics',
      description: 'Check your content performance',
      icon: TrendingUp,
      action: () => onNavigate('analytics'),
      variant: 'outline' as const
    }
  ]

  return (
    <div className="space-y-8">
      {/* Header */}
      <div>
        <motion.h1 
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          className="text-3xl font-bold text-gray-900 mb-2"
        >
          Welcome back! 👋
        </motion.h1>
        <p className="text-gray-600">
          Here's what's happening with your content pipeline today.
        </p>
      </div>

      {/* Stats Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {stats.map((stat, index) => (
          <motion.div
            key={stat.title}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: index * 0.1 }}
          >
            <Card className="p-6" hover>
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-gray-600 mb-1">
                    {stat.title}
                  </p>
                  <p className="text-3xl font-bold text-gray-900">
                    {stat.value}
                  </p>
                  <div className="flex items-center mt-2">
                    <TrendingUp className={`w-4 h-4 mr-1 ${
                      stat.trend === 'up' ? 'text-green-500' : 'text-red-500'
                    }`} />
                    <span className={`text-sm font-medium ${
                      stat.trend === 'up' ? 'text-green-600' : 'text-red-600'
                    }`}>
                      {stat.change}
                    </span>
                  </div>
                </div>
                <div className={`w-12 h-12 bg-gradient-to-r ${stat.color} rounded-xl flex items-center justify-center`}>
                  <stat.icon className="w-6 h-6 text-white" />
                </div>
              </div>
            </Card>
          </motion.div>
        ))}
      </div>

      {/* Quick Actions */}
      <Card className="p-6">
        <h2 className="text-xl font-bold text-gray-900 mb-6">Quick Actions</h2>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          {quickActions.map((action, index) => (
            <motion.div
              key={action.title}
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ delay: 0.4 + index * 0.1 }}
            >
              <div className="p-4 border border-gray-200 rounded-xl hover:border-burgundy-300 transition-colors duration-200">
                <div className="flex items-center mb-3">
                  <div className="w-10 h-10 bg-gradient-to-br from-burgundy-100 to-burgundy-200 rounded-lg flex items-center justify-center mr-3">
                    <action.icon className="w-5 h-5 text-burgundy-600" />
                  </div>
                  <h3 className="font-semibold text-gray-900">{action.title}</h3>
                </div>
                <p className="text-gray-600 text-sm mb-4">{action.description}</p>
                <Button
                  variant={action.variant}
                  onClick={action.action}
                  className="w-full"
                  size="sm"
                >
                  Get Started
                </Button>
              </div>
            </motion.div>
          ))}
        </div>
      </Card>

      {/* Recent Activity */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <Card className="p-6">
          <h2 className="text-xl font-bold text-gray-900 mb-6">Recent Activity</h2>
          <div className="space-y-4">
            {recentActivity.map((activity, index) => (
              <motion.div
                key={activity.id}
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: 0.6 + index * 0.1 }}
                className="flex items-start space-x-3"
              >
                <div className="w-8 h-8 bg-gray-100 rounded-lg flex items-center justify-center flex-shrink-0">
                  <activity.icon className="w-4 h-4 text-gray-600" />
                </div>
                <div className="flex-1 min-w-0">
                  <p className="text-sm font-medium text-gray-900 mb-1">
                    {activity.title}
                  </p>
                  <p className="text-xs text-gray-500">{activity.time}</p>
                </div>
              </motion.div>
            ))}
          </div>
        </Card>

        <Card className="p-6">
          <h2 className="text-xl font-bold text-gray-900 mb-6">Performance Highlights</h2>
          <div className="space-y-4">
            <div className="flex items-center justify-between p-4 bg-green-50 rounded-lg border border-green-200">
              <div className="flex items-center space-x-3">
                <UserPlus className="w-5 h-5 text-green-600" />
                <div>
                  <p className="font-semibold text-green-900">New Wine Club Members</p>
                  <p className="text-sm text-green-700">+15 this month</p>
                </div>
              </div>
              <div className="text-2xl font-bold text-green-600">+23%</div>
            </div>

            <div className="flex items-center justify-between p-4 bg-blue-50 rounded-lg border border-blue-200">
              <div className="flex items-center space-x-3">
                <Eye className="w-5 h-5 text-blue-600" />
                <div>
                  <p className="font-semibold text-blue-900">Blog Engagement</p>
                  <p className="text-sm text-blue-700">Average read time: 3.2 min</p>
                </div>
              </div>
              <div className="text-2xl font-bold text-blue-600">+12%</div>
            </div>

            <div className="flex items-center justify-between p-4 bg-purple-50 rounded-lg border border-purple-200">
              <div className="flex items-center space-x-3">
                <MousePointer className="w-5 h-5 text-purple-600" />
                <div>
                  <p className="font-semibold text-purple-900">Email Click Rate</p>
                  <p className="text-sm text-purple-700">Above industry average</p>
                </div>
              </div>
              <div className="text-2xl font-bold text-purple-600">+8%</div>
            </div>
          </div>
        </Card>
      </div>
    </div>
  )
}