import React, { useState } from 'react'
import { motion } from 'framer-motion'
import { 
  Grape, 
  BarChart3, 
  FileText, 
  Settings, 
  LogOut, 
  Menu, 
  X,
  Calendar,
  Users,
  Sparkles
} from 'lucide-react'
import { useAuth } from '../../hooks/useAuth'
import { useWinery } from '../../hooks/useWinery'
import { Button } from '../ui/Button'
import toast from 'react-hot-toast'

interface DashboardLayoutProps {
  children: React.ReactNode
  currentView: string
  onViewChange: (view: string) => void
}

export function DashboardLayout({ children, currentView, onViewChange }: DashboardLayoutProps) {
  const [sidebarOpen, setSidebarOpen] = useState(false)
  const { signOut } = useAuth()
  const { winery, userRole } = useWinery()

  const handleSignOut = async () => {
    try {
      await signOut()
      toast.success('Signed out successfully')
    } catch (error: any) {
      toast.error(error.message)
    }
  }

  const navigation = [
    { id: 'overview', name: 'Overview', icon: BarChart3 },
    { id: 'content', name: 'Content Pipeline', icon: FileText },
    { id: 'calendar', name: 'Calendar', icon: Calendar },
    { id: 'agents', name: 'AI Agents', icon: Sparkles },
    { id: 'analytics', name: 'Analytics', icon: BarChart3 },
    { id: 'settings', name: 'Settings', icon: Settings },
  ]

  const Sidebar = ({ mobile = false }) => (
    <div className={`${mobile ? 'fixed inset-0 z-50' : 'hidden lg:flex lg:flex-col'} w-64`}>
      {mobile && (
        <div className="fixed inset-0 bg-black/50" onClick={() => setSidebarOpen(false)} />
      )}
      <div className={`${mobile ? 'relative' : ''} flex flex-col h-full bg-white border-r border-gray-200 shadow-lg`}>
        {/* Header */}
        <div className="flex items-center justify-between p-6 border-b border-gray-200">
          <div className="flex items-center space-x-3">
            <div className="w-10 h-10 bg-gradient-to-br from-burgundy-600 to-burgundy-700 rounded-xl flex items-center justify-center">
              <Grape className="w-6 h-6 text-white" />
            </div>
            <div>
              <h1 className="text-lg font-bold text-gray-900 truncate">
                {winery?.winery_name || 'Content Engine'}
              </h1>
              <p className="text-xs text-gray-500 capitalize">
                {userRole?.role?.replace('_', ' ')}
              </p>
            </div>
          </div>
          {mobile && (
            <button
              onClick={() => setSidebarOpen(false)}
              className="p-2 rounded-lg hover:bg-gray-100"
            >
              <X className="w-5 h-5" />
            </button>
          )}
        </div>

        {/* Navigation */}
        <nav className="flex-1 p-4 space-y-2">
          {navigation.map((item) => {
            const isActive = currentView === item.id
            return (
              <motion.button
                key={item.id}
                whileHover={{ x: 4 }}
                whileTap={{ scale: 0.98 }}
                onClick={() => {
                  onViewChange(item.id)
                  if (mobile) setSidebarOpen(false)
                }}
                className={`
                  w-full flex items-center space-x-3 px-4 py-3 rounded-xl text-left transition-all duration-200
                  ${isActive 
                    ? 'bg-gradient-to-r from-burgundy-600 to-burgundy-700 text-white shadow-lg' 
                    : 'text-gray-600 hover:bg-gray-50 hover:text-gray-900'
                  }
                `}
              >
                <item.icon className="w-5 h-5" />
                <span className="font-medium">{item.name}</span>
              </motion.button>
            )
          })}
        </nav>

        {/* Footer */}
        <div className="p-4 border-t border-gray-200">
          <Button
            variant="ghost"
            onClick={handleSignOut}
            className="w-full justify-start text-gray-600 hover:text-red-600 hover:bg-red-50"
          >
            <LogOut className="w-5 h-5 mr-3" />
            Sign Out
          </Button>
        </div>
      </div>
    </div>
  )

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Mobile sidebar */}
      {sidebarOpen && <Sidebar mobile />}
      
      {/* Desktop sidebar */}
      <Sidebar />

      {/* Main content */}
      <div className="lg:ml-64">
        {/* Mobile header */}
        <div className="lg:hidden bg-white border-b border-gray-200 px-4 py-3 flex items-center justify-between">
          <button
            onClick={() => setSidebarOpen(true)}
            className="p-2 rounded-lg hover:bg-gray-100"
          >
            <Menu className="w-6 h-6" />
          </button>
          <div className="flex items-center space-x-2">
            <div className="w-8 h-8 bg-gradient-to-br from-burgundy-600 to-burgundy-700 rounded-lg flex items-center justify-center">
              <Grape className="w-4 h-4 text-white" />
            </div>
            <span className="font-semibold text-gray-900">
              {winery?.winery_name}
            </span>
          </div>
        </div>

        {/* Page content */}
        <main className="p-6">
          {children}
        </main>
      </div>
    </div>
  )
}