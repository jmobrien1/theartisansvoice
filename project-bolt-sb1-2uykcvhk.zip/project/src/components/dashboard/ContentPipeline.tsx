import React, { useState, useEffect } from 'react'
import { motion, AnimatePresence } from 'framer-motion'
import { 
  Plus, 
  FileText, 
  Clock, 
  CheckCircle, 
  Calendar,
  Eye,
  Edit3,
  MessageSquare,
  ExternalLink,
  Filter,
  Search,
  Mail,
  Newspaper,
  Globe,
  Send,
  AlertCircle
} from 'lucide-react'
import { Card } from '../ui/Card'
import { Button } from '../ui/Button'
import { Input } from '../ui/Input'
import { ContentEditor } from '../content/ContentEditor'
import { ContentItem, supabase } from '../../lib/supabase'
import { useWinery } from '../../hooks/useWinery'
import toast from 'react-hot-toast'

export function ContentPipeline() {
  const { winery } = useWinery()
  const [searchTerm, setSearchTerm] = useState('')
  const [filterType, setFilterType] = useState<string>('all')
  const [selectedItem, setSelectedItem] = useState<ContentItem | null>(null)
  const [editingItem, setEditingItem] = useState<ContentItem | null>(null)
  const [contentItems, setContentItems] = useState<ContentItem[]>([])
  const [loading, setLoading] = useState(true)
  const [publishingItems, setPublishingItems] = useState<Set<string>>(new Set())

  // Fetch content items from database
  useEffect(() => {
    if (winery) {
      fetchContentItems()
    }
  }, [winery])

  const fetchContentItems = async () => {
    if (!winery) return

    try {
      setLoading(true)
      const { data, error } = await supabase
        .from('content_calendar')
        .select('*')
        .eq('winery_id', winery.id)
        .order('created_at', { ascending: false })

      if (error) throw error
      setContentItems(data || [])
    } catch (error) {
      console.error('Error fetching content items:', error)
      toast.error('Failed to load content items')
    } finally {
      setLoading(false)
    }
  }

  const handleContentSave = (updatedItem: ContentItem) => {
    setContentItems(prev => 
      prev.map(item => item.id === updatedItem.id ? updatedItem : item)
    )
  }

  const handleStatusUpdate = async (itemId: string, newStatus: ContentItem['status'], approvalComments?: string) => {
    try {
      const updateData: Partial<ContentItem> = {
        status: newStatus,
        updated_at: new Date().toISOString()
      }

      if (approvalComments) {
        updateData.approval_comments = approvalComments
      }

      const { data, error } = await supabase
        .from('content_calendar')
        .update(updateData)
        .eq('id', itemId)
        .select()
        .single()

      if (error) throw error

      setContentItems(prev => 
        prev.map(item => item.id === itemId ? data : item)
      )

      toast.success(`Content ${newStatus.replace('_', ' ')}`)
    } catch (error: any) {
      console.error('Error updating status:', error)
      toast.error('Failed to update content status')
    }
  }

  const handlePublishToWordPress = async (itemId: string) => {
    if (!winery?.wordpress_url) {
      toast.error('WordPress integration not configured. Please update your winery settings.')
      return
    }

    setPublishingItems(prev => new Set(prev).add(itemId))

    try {
      const { data: { session } } = await supabase.auth.getSession()
      if (!session) {
        throw new Error('No active session')
      }

      const response = await fetch(`${import.meta.env.VITE_SUPABASE_URL}/functions/v1/publish-to-wordpress`, {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${session.access_token}`,
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          contentId: itemId,
        }),
      })

      if (!response.ok) {
        const errorData = await response.json()
        throw new Error(errorData.error || 'Failed to publish to WordPress')
      }

      const result = await response.json()
      
      // Update local state
      setContentItems(prev => 
        prev.map(item => 
          item.id === itemId 
            ? { ...item, status: 'published', content_url: result.wordpressUrl, publish_date: new Date().toISOString() }
            : item
        )
      )

      toast.success('Content published to WordPress successfully!')
      
      if (result.warning) {
        toast.error(result.warning, { duration: 6000 })
      }

    } catch (error: any) {
      console.error('Publishing error:', error)
      toast.error(error.message || 'Failed to publish to WordPress')
    } finally {
      setPublishingItems(prev => {
        const newSet = new Set(prev)
        newSet.delete(itemId)
        return newSet
      })
    }
  }

  const statusConfig = {
    draft: { color: 'gray', label: 'Draft', icon: FileText },
    ready_for_review: { color: 'yellow', label: 'Ready for Review', icon: Eye },
    scheduled: { color: 'blue', label: 'Scheduled', icon: Calendar },
    published: { color: 'green', label: 'Published', icon: CheckCircle }
  }

  const typeConfig = {
    blog_post: { label: 'Blog Post', color: 'purple' },
    social_media: { label: 'Social Media', color: 'pink' },
    newsletter: { label: 'Newsletter', color: 'blue' },
    press_release: { label: 'Press Release', color: 'indigo' }
  }

  const filteredItems = contentItems.filter(item => {
    const matchesSearch = item.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         item.content?.toLowerCase().includes(searchTerm.toLowerCase())
    const matchesType = filterType === 'all' || item.content_type === filterType
    return matchesSearch && matchesType
  })

  const groupedItems = {
    draft: filteredItems.filter(item => item.status === 'draft'),
    ready_for_review: filteredItems.filter(item => item.status === 'ready_for_review'),
    scheduled: filteredItems.filter(item => item.status === 'scheduled'),
    published: filteredItems.filter(item => item.status === 'published')
  }

  const ContentCard = ({ item }: { item: ContentItem }) => {
    const status = statusConfig[item.status]
    const type = typeConfig[item.content_type]
    const StatusIcon = status.icon
    const isPublishing = publishingItems.has(item.id)

    const getExcerpt = (content: string | null) => {
      if (!content) return 'No content yet...'
      // Remove HTML tags and get first 100 characters
      const plainText = content.replace(/<[^>]*>/g, ' ').replace(/\s+/g, ' ').trim()
      return plainText.length > 100 ? plainText.substring(0, 100) + '...' : plainText
    }

    const canPublish = (item.status === 'scheduled' || item.status === 'ready_for_review') && 
                      winery?.wordpress_url && 
                      item.content_type === 'blog_post'

    return (
      <motion.div
        layout
        initial={{ opacity: 0, scale: 0.9 }}
        animate={{ opacity: 1, scale: 1 }}
        exit={{ opacity: 0, scale: 0.9 }}
        whileHover={{ y: -2 }}
        className="bg-white rounded-lg border border-gray-200 p-4 shadow-sm hover:shadow-md transition-all duration-200 cursor-pointer"
        onClick={() => setSelectedItem(item)}
      >
        <div className="flex items-start justify-between mb-3">
          <div className="flex items-center space-x-2">
            <StatusIcon className={`w-4 h-4 text-${status.color}-600`} />
            <span className={`text-xs font-medium px-2 py-1 rounded-full bg-${status.color}-100 text-${status.color}-800`}>
              {status.label}
            </span>
          </div>
          <div className="flex items-center space-x-2">
            <span className={`text-xs font-medium px-2 py-1 rounded-full bg-${type.color}-100 text-${type.color}-800`}>
              {type.label}
            </span>
            {canPublish && (
              <Button
                size="sm"
                variant="outline"
                onClick={(e) => {
                  e.stopPropagation()
                  handlePublishToWordPress(item.id)
                }}
                loading={isPublishing}
                disabled={isPublishing}
                className="text-xs px-2 py-1"
              >
                <Globe className="w-3 h-3 mr-1" />
                Publish
              </Button>
            )}
          </div>
        </div>

        <h3 className="font-semibold text-gray-900 mb-2 line-clamp-2">
          {item.title}
        </h3>

        <p className="text-sm text-gray-600 mb-3 line-clamp-2">
          {getExcerpt(item.content)}
        </p>

        <div className="flex items-center justify-between text-xs text-gray-500">
          <span>
            {item.created_by ? 'AI Generated' : 'Manual'}
          </span>
          <div className="flex items-center space-x-2">
            {item.content_url && (
              <a
                href={item.content_url}
                target="_blank"
                rel="noopener noreferrer"
                onClick={(e) => e.stopPropagation()}
                className="text-blue-600 hover:text-blue-800 flex items-center"
              >
                <ExternalLink className="w-3 h-3 mr-1" />
                View Live
              </a>
            )}
            {item.publish_date ? (
              <span>Published {new Date(item.publish_date).toLocaleDateString()}</span>
            ) : (
              <span>Created {new Date(item.created_at).toLocaleDateString()}</span>
            )}
          </div>
        </div>
      </motion.div>
    )
  }

  const ColumnHeader = ({ status, count }: { status: keyof typeof statusConfig, count: number }) => {
    const config = statusConfig[status]
    const StatusIcon = config.icon

    return (
      <div className="flex items-center justify-between mb-4">
        <div className="flex items-center space-x-2">
          <StatusIcon className={`w-5 h-5 text-${config.color}-600`} />
          <h3 className="font-semibold text-gray-900">{config.label}</h3>
          <span className={`text-sm px-2 py-1 rounded-full bg-${config.color}-100 text-${config.color}-800`}>
            {count}
          </span>
        </div>
      </div>
    )
  }

  if (!winery) {
    return (
      <div className="text-center py-12">
        <h2 className="text-2xl font-bold text-gray-900 mb-4">Content Pipeline</h2>
        <p className="text-gray-600">Please complete your winery setup to access the content pipeline.</p>
      </div>
    )
  }

  if (loading) {
    return (
      <div className="text-center py-12">
        <div className="w-16 h-16 bg-gradient-to-br from-burgundy-600 to-burgundy-700 rounded-2xl flex items-center justify-center mx-auto mb-4">
          <div className="w-8 h-8 border-2 border-white border-t-transparent rounded-full animate-spin" />
        </div>
        <p className="text-gray-600">Loading content pipeline...</p>
      </div>
    )
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between gap-4">
        <div>
          <h1 className="text-3xl font-bold text-gray-900">Content Pipeline</h1>
          <p className="text-gray-600 mt-1">
            Manage your content from draft to publication
          </p>
        </div>
        <div className="flex items-center space-x-3">
          {!winery.wordpress_url && (
            <div className="flex items-center space-x-2 text-amber-600 bg-amber-50 px-3 py-2 rounded-lg border border-amber-200">
              <AlertCircle className="w-4 h-4" />
              <span className="text-sm">WordPress not configured</span>
            </div>
          )}
          <Button size="lg">
            <Plus className="w-5 h-5 mr-2" />
            Create Content
          </Button>
        </div>
      </div>

      {/* WordPress Integration Status */}
      {winery.wordpress_url && (
        <Card className="p-4 bg-green-50 border-green-200">
          <div className="flex items-center space-x-3">
            <Globe className="w-5 h-5 text-green-600" />
            <div>
              <p className="font-medium text-green-900">WordPress Integration Active</p>
              <p className="text-sm text-green-700">
                Connected to: {winery.wordpress_url}
              </p>
            </div>
          </div>
        </Card>
      )}

      {/* Filters */}
      <Card className="p-4">
        <div className="flex flex-col lg:flex-row gap-4">
          <div className="flex-1">
            <Input
              placeholder="Search content..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              icon={<Search className="w-4 h-4" />}
            />
          </div>
          <select
            value={filterType}
            onChange={(e) => setFilterType(e.target.value)}
            className="px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-burgundy-500 focus:border-burgundy-500"
          >
            <option value="all">All Types</option>
            <option value="blog_post">Blog Posts</option>
            <option value="social_media">Social Media</option>
            <option value="newsletter">Newsletters</option>
            <option value="press_release">Press Releases</option>
          </select>
        </div>
      </Card>

      {/* Kanban Board */}
      <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
        {Object.entries(groupedItems).map(([status, items]) => (
          <div key={status} className="space-y-4">
            <ColumnHeader 
              status={status as keyof typeof statusConfig} 
              count={items.length} 
            />
            <div className="space-y-3 min-h-[400px]">
              <AnimatePresence>
                {items.map(item => (
                  <ContentCard key={item.id} item={item} />
                ))}
              </AnimatePresence>
              {items.length === 0 && (
                <div className="text-center py-8 text-gray-500">
                  <FileText className="w-8 h-8 mx-auto mb-2 opacity-50" />
                  <p className="text-sm">No items in this stage</p>
                </div>
              )}
            </div>
          </div>
        ))}
      </div>

      {/* Content Detail Modal */}
      <AnimatePresence>
        {selectedItem && !editingItem && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 bg-black/50 flex items-center justify-center p-4 z-50"
            onClick={() => setSelectedItem(null)}
          >
            <motion.div
              initial={{ scale: 0.9, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.9, opacity: 0 }}
              className="bg-white rounded-xl shadow-2xl max-w-2xl w-full max-h-[80vh] overflow-y-auto"
              onClick={(e) => e.stopPropagation()}
            >
              <div className="p-6">
                <div className="flex items-start justify-between mb-4">
                  <div>
                    <h2 className="text-xl font-bold text-gray-900 mb-2">
                      {selectedItem.title}
                    </h2>
                    <div className="flex items-center space-x-3">
                      <span className={`text-xs font-medium px-2 py-1 rounded-full bg-${statusConfig[selectedItem.status].color}-100 text-${statusConfig[selectedItem.status].color}-800`}>
                        {statusConfig[selectedItem.status].label}
                      </span>
                      <span className={`text-xs font-medium px-2 py-1 rounded-full bg-${typeConfig[selectedItem.content_type].color}-100 text-${typeConfig[selectedItem.content_type].color}-800`}>
                        {typeConfig[selectedItem.content_type].label}
                      </span>
                    </div>
                  </div>
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={() => setSelectedItem(null)}
                  >
                    ×
                  </Button>
                </div>

                {selectedItem.content && (
                  <div className="mb-6">
                    <h3 className="font-semibold text-gray-900 mb-2">Content Preview</h3>
                    <div 
                      className="prose max-w-none text-gray-700 bg-gray-50 p-4 rounded-lg"
                      dangerouslySetInnerHTML={{ __html: selectedItem.content }}
                    />
                  </div>
                )}

                <div className="grid grid-cols-2 gap-4 mb-6 text-sm">
                  <div>
                    <span className="font-medium text-gray-900">Created:</span>
                    <span className="ml-2 text-gray-600">
                      {new Date(selectedItem.created_at).toLocaleDateString()}
                    </span>
                  </div>
                  <div>
                    <span className="font-medium text-gray-900">Type:</span>
                    <span className="ml-2 text-gray-600">{typeConfig[selectedItem.content_type].label}</span>
                  </div>
                  {selectedItem.publish_date && (
                    <div>
                      <span className="font-medium text-gray-900">Publish Date:</span>
                      <span className="ml-2 text-gray-600">
                        {new Date(selectedItem.publish_date).toLocaleDateString()}
                      </span>
                    </div>
                  )}
                  {selectedItem.content_url && (
                    <div>
                      <span className="font-medium text-gray-900">Live URL:</span>
                      <a
                        href={selectedItem.content_url}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="ml-2 text-blue-600 hover:text-blue-800 text-sm flex items-center"
                      >
                        <ExternalLink className="w-3 h-3 mr-1" />
                        View Post
                      </a>
                    </div>
                  )}
                  {selectedItem.approval_comments && (
                    <div className="col-span-2">
                      <span className="font-medium text-gray-900">Comments:</span>
                      <p className="mt-1 text-gray-600 text-sm">{selectedItem.approval_comments}</p>
                    </div>
                  )}
                </div>

                <div className="flex space-x-3">
                  <Button 
                    size="sm"
                    onClick={() => {
                      setEditingItem(selectedItem)
                      setSelectedItem(null)
                    }}
                  >
                    <Edit3 className="w-4 h-4 mr-2" />
                    Edit Content
                  </Button>
                  
                  {selectedItem.status === 'draft' && (
                    <Button 
                      variant="secondary" 
                      size="sm"
                      onClick={() => handleStatusUpdate(selectedItem.id, 'ready_for_review')}
                    >
                      <Eye className="w-4 h-4 mr-2" />
                      Submit for Review
                    </Button>
                  )}
                  
                  {selectedItem.status === 'ready_for_review' && (
                    <>
                      <Button 
                        variant="secondary" 
                        size="sm"
                        onClick={() => handleStatusUpdate(selectedItem.id, 'scheduled')}
                      >
                        <CheckCircle className="w-4 h-4 mr-2" />
                        Approve
                      </Button>
                      <Button 
                        variant="outline" 
                        size="sm"
                        onClick={() => handleStatusUpdate(selectedItem.id, 'draft', 'Needs revisions')}
                      >
                        <MessageSquare className="w-4 h-4 mr-2" />
                        Request Changes
                      </Button>
                    </>
                  )}
                  
                  {(selectedItem.status === 'scheduled' || selectedItem.status === 'ready_for_review') && 
                   winery?.wordpress_url && 
                   selectedItem.content_type === 'blog_post' && (
                    <Button 
                      variant="secondary" 
                      size="sm"
                      onClick={() => handlePublishToWordPress(selectedItem.id)}
                      loading={publishingItems.has(selectedItem.id)}
                    >
                      <Send className="w-4 h-4 mr-2" />
                      Publish to WordPress
                    </Button>
                  )}
                  
                  {selectedItem.status === 'published' && selectedItem.content_url && (
                    <Button 
                      variant="outline" 
                      size="sm"
                      onClick={() => window.open(selectedItem.content_url, '_blank')}
                    >
                      <ExternalLink className="w-4 h-4 mr-2" />
                      View Published
                    </Button>
                  )}
                </div>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Content Editor Modal */}
      <AnimatePresence>
        {editingItem && (
          <ContentEditor
            item={editingItem}
            onClose={() => setEditingItem(null)}
            onSave={handleContentSave}
          />
        )}
      </AnimatePresence>
    </div>
  )
}