import React, { useState } from 'react'
import { DashboardLayout } from './dashboard/DashboardLayout'
import { OverviewDashboard } from './dashboard/OverviewDashboard'
import { ContentPipeline } from './dashboard/ContentPipeline'
import { ContentCalendar } from './dashboard/ContentCalendar'
import { AIAgents } from './dashboard/AIAgents'

export function Dashboard() {
  const [currentView, setCurrentView] = useState('overview')

  const renderView = () => {
    switch (currentView) {
      case 'overview':
        return <OverviewDashboard onNavigate={setCurrentView} />
      case 'content':
        return <ContentPipeline />
      case 'calendar':
        return <ContentCalendar />
      case 'agents':
        return <AIAgents />
      case 'analytics':
        return (
          <div className="text-center py-12">
            <h2 className="text-2xl font-bold text-gray-900 mb-4">Analytics Dashboard</h2>
            <p className="text-gray-600">Coming soon - Detailed engagement metrics and performance insights</p>
          </div>
        )
      case 'settings':
        return (
          <div className="text-center py-12">
            <h2 className="text-2xl font-bold text-gray-900 mb-4">Settings</h2>
            <p className="text-gray-600">Coming soon - Winery profile management and integration settings</p>
          </div>
        )
      default:
        return <OverviewDashboard onNavigate={setCurrentView} />
    }
  }

  return (
    <DashboardLayout currentView={currentView} onViewChange={setCurrentView}>
      {renderView()}
    </DashboardLayout>
  )
}