import React, { useState } from 'react'
import { motion, AnimatePresence } from 'framer-motion'
import { ChevronLeft, ChevronRight, Grape, MapPin, User, MessageCircle, Users, Target, Calendar } from 'lucide-react'
import { useWinery } from '../../hooks/useWinery'
import { Button } from '../ui/Button'
import { Input } from '../ui/Input'
import { Card } from '../ui/Card'
import toast from 'react-hot-toast'

interface FormData {
  winery_name: string
  location: string
  owner_name: string
  brand_tone: string
  backstory: string
  wines: string
  target_audience: string
  weekly_content_goals: number
  wordpress_url: string
  wordpress_username: string
  wordpress_password: string
}

export function OnboardingWizard() {
  const [currentStep, setCurrentStep] = useState(0)
  const [loading, setLoading] = useState(false)
  const { createWinery } = useWinery()

  const [formData, setFormData] = useState<FormData>({
    winery_name: '',
    location: '',
    owner_name: '',
    brand_tone: '',
    backstory: '',
    wines: '',
    target_audience: '',
    weekly_content_goals: 3,
    wordpress_url: '',
    wordpress_username: '',
    wordpress_password: '',
  })

  const [errors, setErrors] = useState<Partial<FormData>>({})

  const steps = [
    {
      title: 'Winery Details',
      description: 'Tell us about your winery',
      icon: Grape,
      fields: ['winery_name', 'location', 'owner_name']
    },
    {
      title: 'Brand Voice',
      description: 'Define your unique voice',
      icon: MessageCircle,
      fields: ['brand_tone', 'backstory']
    },
    {
      title: 'Products & Audience',
      description: 'Your wines and customers',
      icon: Users,
      fields: ['wines', 'target_audience']
    },
    {
      title: 'Content Goals',
      description: 'Set your publishing schedule',
      icon: Target,
      fields: ['weekly_content_goals']
    },
    {
      title: 'WordPress Integration',
      description: 'Connect your website (optional)',
      icon: Calendar,
      fields: [] // No required fields for this step
    }
  ]

  const updateField = (field: keyof FormData, value: string | number) => {
    setFormData(prev => ({ ...prev, [field]: value }))
    // Clear error when user starts typing
    if (errors[field]) {
      setErrors(prev => ({ ...prev, [field]: undefined }))
    }
  }

  const validateCurrentStep = () => {
    const currentStepFields = steps[currentStep].fields
    const newErrors: Partial<FormData> = {}

    currentStepFields.forEach(field => {
      const value = formData[field as keyof FormData]
      
      if (field === 'backstory') {
        if (!value || typeof value !== 'string' || value.trim().length < 50) {
          newErrors[field as keyof FormData] = 'Please provide at least 50 characters'
        }
      } else if (field === 'weekly_content_goals') {
        if (!value || typeof value !== 'number' || value < 1) {
          newErrors[field as keyof FormData] = 'Please select at least 1 post per week'
        }
      } else {
        if (!value || typeof value !== 'string' || value.trim().length === 0) {
          newErrors[field as keyof FormData] = 'This field is required'
        }
      }
    })

    setErrors(newErrors)
    return Object.keys(newErrors).length === 0
  }

  const nextStep = () => {
    if (validateCurrentStep()) {
      if (currentStep < steps.length - 1) {
        setCurrentStep(currentStep + 1)
        setErrors({}) // Clear errors when moving to next step
      }
    }
  }

  const prevStep = () => {
    if (currentStep > 0) {
      setCurrentStep(currentStep - 1)
      setErrors({}) // Clear errors when moving back
    }
  }

  const onSubmit = async () => {
    setLoading(true)
    try {
      const cleanedData = {
        ...formData,
        wordpress_url: formData.wordpress_url || undefined,
        wordpress_username: formData.wordpress_username || undefined,
        wordpress_password: formData.wordpress_password || undefined,
        wines: formData.wines.split(',').map(wine => wine.trim()),
      }
      
      await createWinery(cleanedData)
      toast.success('Winery profile created successfully!')
    } catch (error: any) {
      toast.error(error.message || 'An error occurred')
    } finally {
      setLoading(false)
    }
  }

  const canProceedToNextStep = () => {
    const currentStepFields = steps[currentStep].fields
    
    // For the last step (WordPress), always allow proceeding since fields are optional
    if (currentStep === steps.length - 1) {
      return true
    }
    
    // Check each required field for the current step
    return currentStepFields.every(field => {
      const value = formData[field as keyof FormData]
      
      if (field === 'backstory') {
        return value && typeof value === 'string' && value.trim().length >= 50
      } else if (field === 'weekly_content_goals') {
        return value && typeof value === 'number' && value >= 1
      } else {
        return value && typeof value === 'string' && value.trim().length > 0
      }
    })
  }

  const StepIcon = steps[currentStep].icon

  return (
    <div className="min-h-screen bg-gradient-to-br from-burgundy-50 via-white to-amber-50 p-4">
      <div className="max-w-4xl mx-auto py-12">
        {/* Header */}
        <div className="text-center mb-12">
          <motion.div
            initial={{ scale: 0 }}
            animate={{ scale: 1 }}
            className="mx-auto w-20 h-20 bg-gradient-to-br from-burgundy-600 to-burgundy-700 rounded-3xl flex items-center justify-center mb-6"
          >
            <Grape className="w-10 h-10 text-white" />
          </motion.div>
          <h1 className="text-4xl font-bold bg-gradient-to-r from-burgundy-600 to-burgundy-800 bg-clip-text text-transparent mb-4">
            Welcome to Your Content Engine
          </h1>
          <p className="text-xl text-gray-600">
            Let's set up your winery profile to create amazing content
          </p>
        </div>

        {/* Progress Bar */}
        <div className="mb-8">
          <div className="flex items-center justify-between mb-4">
            {steps.map((step, index) => (
              <div
                key={index}
                className={`flex items-center ${index < steps.length - 1 ? 'flex-1' : ''}`}
              >
                <div
                  className={`w-10 h-10 rounded-full flex items-center justify-center transition-all duration-300 ${
                    index <= currentStep
                      ? 'bg-gradient-to-r from-burgundy-600 to-burgundy-700 text-white'
                      : 'bg-gray-200 text-gray-400'
                  }`}
                >
                  {index + 1}
                </div>
                {index < steps.length - 1 && (
                  <div
                    className={`flex-1 h-1 mx-4 transition-all duration-300 ${
                      index < currentStep ? 'bg-burgundy-600' : 'bg-gray-200'
                    }`}
                  />
                )}
              </div>
            ))}
          </div>
          <div className="text-center">
            <span className="text-sm text-gray-500">
              Step {currentStep + 1} of {steps.length}
            </span>
          </div>
        </div>

        {/* Form */}
        <Card className="p-8">
          <AnimatePresence mode="wait">
            <motion.div
              key={currentStep}
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -20 }}
              transition={{ duration: 0.3 }}
            >
              <div className="text-center mb-8">
                <div className="mx-auto w-16 h-16 bg-gradient-to-br from-burgundy-100 to-burgundy-200 rounded-2xl flex items-center justify-center mb-4">
                  <StepIcon className="w-8 h-8 text-burgundy-600" />
                </div>
                <h2 className="text-2xl font-bold text-gray-900 mb-2">
                  {steps[currentStep].title}
                </h2>
                <p className="text-gray-600">
                  {steps[currentStep].description}
                </p>
              </div>

              <div className="space-y-6">
                {currentStep === 0 && (
                  <>
                    <Input
                      label="Winery Name"
                      placeholder="Enter your winery name"
                      value={formData.winery_name}
                      onChange={(e) => updateField('winery_name', e.target.value)}
                      error={errors.winery_name}
                      icon={<Grape className="w-5 h-5" />}
                    />
                    <Input
                      label="Location"
                      placeholder="e.g., Loudoun County, VA"
                      value={formData.location}
                      onChange={(e) => updateField('location', e.target.value)}
                      error={errors.location}
                      icon={<MapPin className="w-5 h-5" />}
                    />
                    <Input
                      label="Owner Name"
                      placeholder="Enter the owner's name"
                      value={formData.owner_name}
                      onChange={(e) => updateField('owner_name', e.target.value)}
                      error={errors.owner_name}
                      icon={<User className="w-5 h-5" />}
                    />
                  </>
                )}

                {currentStep === 1 && (
                  <>
                    <Input
                      label="Brand Tone"
                      placeholder="e.g., Elegant and sophisticated, Rustic and approachable"
                      value={formData.brand_tone}
                      onChange={(e) => updateField('brand_tone', e.target.value)}
                      error={errors.brand_tone}
                    />
                    <div className="space-y-1">
                      <label className="block text-sm font-medium text-gray-700">
                        Backstory
                      </label>
                      <textarea
                        value={formData.backstory}
                        onChange={(e) => updateField('backstory', e.target.value)}
                        placeholder="Tell the story of your winery - its history, passion, and what makes it unique..."
                        rows={6}
                        className={`block w-full px-3 py-2 border rounded-lg focus:ring-2 focus:ring-burgundy-500 focus:border-burgundy-500 placeholder-gray-500 transition-colors duration-200 ${
                          errors.backstory ? 'border-red-500' : 'border-gray-300'
                        }`}
                      />
                      {errors.backstory && (
                        <p className="text-sm text-red-600">{errors.backstory}</p>
                      )}
                      <p className="text-xs text-gray-500">
                        {formData.backstory.length}/50 characters minimum
                      </p>
                    </div>
                  </>
                )}

                {currentStep === 2 && (
                  <>
                    <div className="space-y-1">
                      <label className="block text-sm font-medium text-gray-700">
                        Wines & Varietals
                      </label>
                      <textarea
                        value={formData.wines}
                        onChange={(e) => updateField('wines', e.target.value)}
                        placeholder="List your wines (comma-separated): Chardonnay, Cabernet Sauvignon, Pinot Noir..."
                        rows={3}
                        className={`block w-full px-3 py-2 border rounded-lg focus:ring-2 focus:ring-burgundy-500 focus:border-burgundy-500 placeholder-gray-500 transition-colors duration-200 ${
                          errors.wines ? 'border-red-500' : 'border-gray-300'
                        }`}
                      />
                      {errors.wines && (
                        <p className="text-sm text-red-600">{errors.wines}</p>
                      )}
                    </div>
                    <Input
                      label="Target Audience"
                      placeholder="e.g., Wine enthusiasts, Local food lovers, Event planners"
                      value={formData.target_audience}
                      onChange={(e) => updateField('target_audience', e.target.value)}
                      error={errors.target_audience}
                    />
                  </>
                )}

                {currentStep === 3 && (
                  <div className="space-y-6">
                    <div className="space-y-1">
                      <label className="block text-sm font-medium text-gray-700">
                        Weekly Content Goals
                      </label>
                      <div className="flex items-center space-x-4">
                        <input
                          type="range"
                          min="1"
                          max="10"
                          value={formData.weekly_content_goals}
                          onChange={(e) => updateField('weekly_content_goals', parseInt(e.target.value))}
                          className="flex-1 h-2 bg-gray-200 rounded-lg appearance-none cursor-pointer"
                        />
                        <span className="text-lg font-semibold text-burgundy-600 min-w-[3rem]">
                          {formData.weekly_content_goals} posts
                        </span>
                      </div>
                      <p className="text-sm text-gray-500">
                        How many pieces of content would you like to publish per week?
                      </p>
                    </div>
                  </div>
                )}

                {currentStep === 4 && (
                  <>
                    <Input
                      label="WordPress URL (Optional)"
                      placeholder="https://yourwinery.com"
                      value={formData.wordpress_url}
                      onChange={(e) => updateField('wordpress_url', e.target.value)}
                    />
                    <Input
                      label="WordPress Username (Optional)"
                      placeholder="Enter your WordPress username"
                      value={formData.wordpress_username}
                      onChange={(e) => updateField('wordpress_username', e.target.value)}
                    />
                    <Input
                      type="password"
                      label="WordPress Password (Optional)"
                      placeholder="Enter your WordPress password"
                      value={formData.wordpress_password}
                      onChange={(e) => updateField('wordpress_password', e.target.value)}
                    />
                    <div className="bg-amber-50 border border-amber-200 rounded-lg p-4">
                      <p className="text-sm text-amber-800">
                        <strong>Note:</strong> WordPress integration allows automatic publishing of approved content to your website. This is optional and can be configured later.
                      </p>
                    </div>
                  </>
                )}
              </div>
            </motion.div>
          </AnimatePresence>

          {/* Navigation */}
          <div className="flex justify-between mt-8">
            <Button
              type="button"
              variant="ghost"
              onClick={prevStep}
              disabled={currentStep === 0}
              className={currentStep === 0 ? 'invisible' : ''}
            >
              <ChevronLeft className="w-4 h-4 mr-2" />
              Previous
            </Button>

            {currentStep === steps.length - 1 ? (
              <Button
                type="button"
                onClick={onSubmit}
                loading={loading}
                size="lg"
              >
                Complete Setup
                <Grape className="w-4 h-4 ml-2" />
              </Button>
            ) : (
              <Button
                type="button"
                onClick={nextStep}
                disabled={!canProceedToNextStep()}
                size="lg"
              >
                Next
                <ChevronRight className="w-4 h-4 ml-2" />
              </Button>
            )}
          </div>
        </Card>
      </div>
    </div>
  )
}