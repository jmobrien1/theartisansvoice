/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{js,ts,jsx,tsx}'],
  theme: {
    extend: {
      colors: {
        background: '#ffffff',
        foreground: '#374151',
        border: '#e5e7eb',
        burgundy: {
          50: '#fef7f7',
          100: '#fdeaea',
          200: '#fbd9d9',
          300: '#f7bbbb',
          400: '#f29090',
          500: '#ea6666',
          600: '#d53f3f',
          700: '#b22c2c',
          800: '#942727',
          900: '#7c2626',
          950: '#431010',
        },
        amber: {
          50: '#fffbeb',
          100: '#fef3c7',
          200: '#fde68a',
          300: '#fcd34d',
          400: '#fbbf24',
          500: '#f59e0b',
          600: '#d97706',
          700: '#b45309',
          800: '#92400e',
          900: '#78350f',
          950: '#451a03',
        }
      },
      fontFamily: {
        sans: ['Inter', 'system-ui', 'sans-serif'],
      },
      animation: {
        'fade-in': 'fadeIn 0.5s ease-in-out',
        'slide-up': 'slideUp 0.3s ease-out',
        'scale-in': 'scaleIn 0.2s ease-out',
      },
      keyframes: {
        fadeIn: {
          '0%': { opacity: '0' },
          '100%': { opacity: '1' },
        },
        slideUp: {
          '0%': { transform: 'translateY(10px)', opacity: '0' },
          '100%': { transform: 'translateY(0)', opacity: '1' },
        },
        scaleIn: {
          '0%': { transform: 'scale(0.95)', opacity: '0' },
          '100%': { transform: 'scale(1)', opacity: '1' },
        },
      },
      backdropBlur: {
        xs: '2px',
      },
    },
  },
  plugins: [],
  safelist: [
    // Dynamic color classes for status indicators
    'bg-gray-100', 'bg-yellow-100', 'bg-blue-100', 'bg-green-100',
    'text-gray-600', 'text-yellow-800', 'text-blue-800', 'text-green-800',
    'border-gray-200', 'border-yellow-200', 'border-blue-200', 'border-green-200',
    'text-gray-600', 'text-yellow-600', 'text-blue-600', 'text-green-600',
    // Dynamic gradient classes for agents
    'from-blue-500', 'to-blue-600', 'from-purple-500', 'to-purple-600',
    'from-green-500', 'to-green-600', 'from-amber-500', 'to-amber-600',
    // Dynamic type indicator classes
    'bg-purple-100', 'text-purple-800', 'bg-pink-100', 'text-pink-800',
    'bg-indigo-100', 'text-indigo-800',
  ],
}